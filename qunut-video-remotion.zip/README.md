# Video Remotion Fikih — Qunut Subuh (9:16, 1080×1920, 30 fps)

Voice-over asli `public/qunut_edit.mp3` (152,592 dtk) adalah master timeline. Durasi komposisi dibaca dari MP3 lewat `calculateMetadata` (`getAudioDurationInSeconds`), fallback 4578 frame.

## Menjalankan
```bash
npm install
npm start            # Remotion Studio (preview), pilih komposisi "QunutFikih"
npm run typecheck
npm run render       # → out/qunut-fikih.mp4 (H.264 + AAC, CRF 18)
```
Render penuh butuh CPU memadai (4578 frame). Jika Chrome tidak terunduh otomatis: `npx remotion browser ensure`, atau tambahkan `--browser-executable=/path/chrome`.

## Struktur
- `src/data/timeline.ts` — segmen narasi bertimestamp, batas adegan, waktu kata Arab & terjemahan
- `src/scenes/` — Adegan A–H (satu file per adegan)
- `src/components/` — Backdrop, Mosque, PrayerFigure, PrayerSequence, Text (kinetic/Arab RTL), Panels, Transitions
- `src/Composition.tsx` — audio (VO + musik + SFX), adegan, transisi, tirai awal/akhir
- `scripts/gen_audio.py` — sintesis SFX & musik latar orisinal → `public/audio/` (sudah dibuat)
- `docs/transkrip-whisper.json` — transkripsi berpenanda waktu per kata (dasar sinkronisasi)
- `docs/LAPORAN.md` — catatan ilmiah & kendala
