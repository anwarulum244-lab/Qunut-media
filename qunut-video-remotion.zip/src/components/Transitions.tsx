import React from "react";
import {AbsoluteFill} from "remotion";
import {C, H, W} from "../theme";
import {clamp, easeInOut, seg, useT} from "../helpers/anim";
import {STAR8} from "./Ornaments";

type Kind = "slab-right" | "slab-left" | "slab-up" | "manuscript" | "geo" | "iris";
export type TransitionDef = {cut: number; h: number; kind: Kind};

/** Transisi antaradegan; titik potong (cut) = batas adegan pada narasi. */
export const TRANSITIONS: TransitionDef[] = [
  {cut: 12.8, h: 0.5, kind: "slab-right"},
  {cut: 41.55, h: 0.6, kind: "manuscript"},
  {cut: 69.48, h: 0.45, kind: "slab-left"},
  {cut: 119.43, h: 0.5, kind: "geo"},
  {cut: 125.15, h: 0.4, kind: "slab-up"},
  {cut: 132.6, h: 0.5, kind: "iris"},
  {cut: 141.6, h: 0.55, kind: "geo"},
];

const Slab: React.FC<{p: number; dir: "right" | "left" | "up"}> = ({p, dir}) => {
  const e = easeInOut(p);
  const vertical = dir === "up";
  const len = (vertical ? H : W) * 1.9;
  const off = (e * 2 - 1) * len * (dir === "left" ? -1 : dir === "up" ? -1 : 1);
  return (
    <AbsoluteFill style={{overflow: "hidden"}}>
      <div
        style={{
          position: "absolute",
          left: vertical ? -W * 0.3 : -(len - W) / 2,
          top: vertical ? -(len - H) / 2 : -H * 0.2,
          width: vertical ? W * 1.6 : len,
          height: vertical ? len : H * 1.4,
          transform: `${vertical ? `translateY(${off}px) skewY(-8deg)` : `translateX(${off}px) skewX(-12deg)`}`,
          background: `linear-gradient(${vertical ? 180 : 90}deg, ${C.gold} 0%, ${C.goldLight} 1.5%, ${C.emerald} 3.5%, ${C.emeraldDeep} 50%, ${C.emerald} 96.5%, ${C.goldLight} 98.5%, ${C.gold} 100%)`,
          boxShadow: `0 0 120px ${C.gold}99`,
        }}
      >
        <svg width="100%" height="100%" style={{opacity: 0.18}}>
          <defs>
            <pattern id={`slab-${dir}`} width="120" height="120" patternUnits="userSpaceOnUse">
              <path d={STAR8} transform="scale(1.2)" fill="none" stroke={C.goldLight} strokeWidth="1.2" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill={`url(#slab-${dir})`} />
        </svg>
      </div>
    </AbsoluteFill>
  );
};

const Doors: React.FC<{p: number}> = ({p}) => {
  const a = seg(p, 0, 0.4, easeInOut);
  const b = seg(p, 0.52, 1, easeInOut);
  const panel = (side: "l" | "r") => {
    const left = side === "l";
    return (
      <div
        style={{
          position: "absolute",
          top: 0,
          [left ? "left" : "right"]: 0,
          width: W / 2,
          height: H,
          transformOrigin: left ? "left center" : "right center",
          transform: `translateX(${(left ? -1 : 1) * (1 - a) * (W / 2)}px) rotateY(${(left ? 1 : -1) * b * 112}deg)`,
          background: `linear-gradient(${left ? 90 : 270}deg, ${C.parchmentDark} 0%, ${C.parchment} 55%, #fff4d2 100%)`,
          boxShadow: `inset ${left ? -40 : 40}px 0 80px #8f6a2299`,
          borderLeft: left ? undefined : `6px solid ${C.goldDeep}`,
          borderRight: left ? `6px solid ${C.goldDeep}` : undefined,
          opacity: 1 - seg(p, 0.9, 1),
          backfaceVisibility: "hidden",
        }}
      >
        <svg width="100%" height="100%" style={{opacity: 0.32}}>
          {Array.from({length: 22}).map((_, i) => (
            <line key={i} x1={left ? 60 : 40} x2={left ? W / 2 - 40 : W / 2 - 60} y1={170 + i * 70} y2={170 + i * 70} stroke={C.goldDeep} strokeWidth={2} strokeDasharray={`${40 + ((i * 37) % 120)} ${10 + ((i * 17) % 30)}`} />
          ))}
        </svg>
      </div>
    );
  };
  return (
    <AbsoluteFill style={{perspective: 2600, overflow: "hidden"}}>
      {panel("l")}
      {panel("r")}
      <div style={{position: "absolute", left: W / 2 - 4, top: 0, width: 8, height: H, background: C.gold, opacity: a * (1 - b) * 0.9, boxShadow: `0 0 50px ${C.gold}`}} />
    </AbsoluteFill>
  );
};

const starPoints = (R: number, n = 8, inner = 0.62) => {
  const pts: string[] = [];
  for (let i = 0; i < n * 2; i++) {
    const r = i % 2 === 0 ? R : R * inner;
    const a = (Math.PI * i) / n - Math.PI / 2;
    pts.push(`${W / 2 + Math.cos(a) * r},${H / 2 + Math.sin(a) * r}`);
  }
  return pts.join(" ");
};

const ShapeWipe: React.FC<{p: number; shape: "star" | "circle"; id: string}> = ({p, shape, id}) => {
  const R = 2000;
  const grow = (x: number) => easeInOut(clamp(x));
  const fillR = R * grow(p / 0.5);
  const holeR = R * grow((p - 0.5) / 0.5);
  const shapeEl = (r: number, extra: React.SVGProps<SVGElement> & Record<string, unknown> = {}) =>
    shape === "star" ? <polygon points={starPoints(r)} {...(extra as object)} /> : <circle cx={W / 2} cy={H / 2} r={r} {...(extra as object)} />;
  return (
    <AbsoluteFill>
      <svg width={W} height={H}>
        <defs>
          <radialGradient id={`${id}-g`} cx="50%" cy="50%" r="70%">
            <stop offset="0" stopColor={C.emerald} />
            <stop offset="1" stopColor={C.emeraldDeep} />
          </radialGradient>
          <mask id={`${id}-m`}>
            <rect width={W} height={H} fill="white" />
            {shapeEl(holeR, {fill: "black"})}
          </mask>
        </defs>
        {p < 0.5 ? (
          <>
            {shapeEl(fillR, {fill: `url(#${id}-g)`, stroke: C.gold, strokeWidth: 6})}
            {shapeEl(fillR * 0.9, {fill: "none", stroke: C.goldLight, strokeWidth: 1.5, opacity: 0.6})}
          </>
        ) : (
          <>
            <rect width={W} height={H} fill={`url(#${id}-g)`} mask={`url(#${id}-m)`} />
            {holeR > 4 && shapeEl(holeR, {fill: "none", stroke: C.gold, strokeWidth: 6})}
          </>
        )}
      </svg>
    </AbsoluteFill>
  );
};

export const Transitions: React.FC = () => {
  const t = useT();
  return (
    <>
      {TRANSITIONS.map((tr, i) => {
        const p = (t - (tr.cut - tr.h)) / (2 * tr.h);
        if (p <= 0 || p >= 1) return null;
        switch (tr.kind) {
          case "slab-right":
            return <Slab key={i} p={p} dir="right" />;
          case "slab-left":
            return <Slab key={i} p={p} dir="left" />;
          case "slab-up":
            return <Slab key={i} p={p} dir="up" />;
          case "manuscript":
            return <Doors key={i} p={p} />;
          case "geo":
            return <ShapeWipe key={i} p={p} shape="star" id={`tr${i}`} />;
          default:
            return <ShapeWipe key={i} p={p} shape="circle" id={`tr${i}`} />;
        }
      })}
    </>
  );
};
