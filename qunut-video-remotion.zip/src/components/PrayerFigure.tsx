import React from "react";
import {C} from "../theme";
import {lerp} from "../helpers/anim";

type P = [number, number];
export type Pose = {head: P; neck: P; shoulder: P; elbow: P; hand: P; hip: P; knee: P; ankle: P; toe: P};

/** Figur siluet netral (tanpa wajah), menghadap ke kanan (arah kiblat). Koordinat dalam kotak 300x300. */
export const POSES: Record<"qiyam" | "rukuk" | "itidal" | "sujud", Pose> = {
  qiyam: {head: [101, 46], neck: [99, 66], shoulder: [98, 80], elbow: [106, 112], hand: [126, 92], hip: [95, 148], knee: [98, 208], ankle: [96, 268], toe: [120, 271]},
  itidal: {head: [101, 46], neck: [99, 66], shoulder: [98, 80], elbow: [100, 118], hand: [104, 158], hip: [95, 148], knee: [98, 208], ankle: [96, 268], toe: [120, 271]},
  rukuk: {head: [186, 150], neck: [162, 150], shoulder: [152, 150], elbow: [140, 180], hand: [116, 207], hip: [88, 152], knee: [112, 208], ankle: [100, 268], toe: [124, 271]},
  sujud: {head: [243, 257], neck: [224, 246], shoulder: [208, 236], elbow: [200, 258], hand: [226, 270], hip: [150, 203], knee: [120, 266], ankle: [62, 266], toe: [42, 268]},
};

const RAISED = {elbow: [120, 106] as P, hand: [142, 82] as P};

export const blendPose = (a: Pose, b: Pose, k: number): Pose => {
  const m = (p: P, q: P): P => [lerp(p[0], q[0], k), lerp(p[1], q[1], k)];
  return {
    head: m(a.head, b.head), neck: m(a.neck, b.neck), shoulder: m(a.shoulder, b.shoulder), elbow: m(a.elbow, b.elbow),
    hand: m(a.hand, b.hand), hip: m(a.hip, b.hip), knee: m(a.knee, b.knee), ankle: m(a.ankle, b.ankle), toe: m(a.toe, b.toe),
  };
};

const pl = (pts: P[]) => pts.map((p) => p.join(",")).join(" ");

/** raise 0..1: tangan terangkat (posisi doa qunut) menggantikan posisi tangan biasa. */
export const PrayerFigure: React.FC<{pose: Pose; raise?: number; size?: number; color?: string; accent?: string; glow?: boolean}> = ({
  pose,
  raise = 0,
  size = 600,
  color = C.goldLight,
  accent = C.ivory,
  glow = false,
}) => {
  const elbow: P = [lerp(pose.elbow[0], RAISED.elbow[0] + (pose.shoulder[0] - 98), raise), lerp(pose.elbow[1], RAISED.elbow[1] + (pose.shoulder[1] - 80), raise)];
  const hand: P = [lerp(pose.hand[0], RAISED.hand[0] + (pose.shoulder[0] - 98), raise), lerp(pose.hand[1], RAISED.hand[1] + (pose.shoulder[1] - 80), raise)];
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 300 300"
      style={{overflow: "visible", filter: glow ? `drop-shadow(0 0 18px ${C.gold}aa)` : undefined}}
    >
      {/* sajadah */}
      <rect x={10} y={274} width={280} height={14} rx={7} fill={C.emerald} stroke={C.gold} strokeWidth={1.6} />
      <g strokeLinecap="round" strokeLinejoin="round" fill="none">
        <polyline points={pl([pose.hip, pose.knee, pose.ankle, pose.toe])} stroke={color} strokeWidth={21} opacity={0.92} />
        <line x1={pose.hip[0]} y1={pose.hip[1]} x2={pose.shoulder[0]} y2={pose.shoulder[1]} stroke={color} strokeWidth={36} />
        <line x1={pose.shoulder[0]} y1={pose.shoulder[1]} x2={pose.neck[0]} y2={pose.neck[1]} stroke={color} strokeWidth={16} />
        <polyline points={pl([pose.shoulder, elbow, hand])} stroke={accent} strokeWidth={13} />
      </g>
      <circle cx={pose.head[0]} cy={pose.head[1]} r={17} fill={color} />
      <circle cx={hand[0]} cy={hand[1]} r={8.5} fill={accent} />
      {raise > 0.2 && (
        <path
          d={`M ${hand[0] - 10} ${hand[1] - 4} q 10 14 22 0`}
          stroke={accent}
          strokeWidth={4}
          fill="none"
          strokeLinecap="round"
          opacity={raise}
        />
      )}
    </svg>
  );
};
