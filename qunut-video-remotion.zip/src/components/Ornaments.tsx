import React from "react";
import {C} from "../theme";

export const STAR8 =
  "M50 2 L61 31 L90 17 L76 46 L98 50 L76 54 L90 83 L61 69 L50 98 L39 69 L10 83 L24 54 L2 50 L24 46 L10 17 L39 31 Z";

export const Star8: React.FC<{size: number; color?: string; fill?: string; stroke?: number; rotate?: number; opacity?: number}> = ({
  size,
  color = C.gold,
  fill = "none",
  stroke = 2,
  rotate = 0,
  opacity = 1,
}) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{transform: `rotate(${rotate}deg)`, opacity}}>
    <path d={STAR8} fill={fill} stroke={color} strokeWidth={stroke} strokeLinejoin="round" />
  </svg>
);

/** Garis pembatas emas dengan berlian di tengah; progress 0..1 menggambar dari tengah. */
export const GoldDivider: React.FC<{width: number; progress?: number; color?: string}> = ({width, progress = 1, color = C.gold}) => {
  const half = (width / 2 - 24) * progress;
  return (
    <svg width={width} height={28} viewBox={`0 0 ${width} 28`}>
      <line x1={width / 2 - 18 - half} y1={14} x2={width / 2 - 18} y2={14} stroke={color} strokeWidth={2} strokeLinecap="round" />
      <line x1={width / 2 + 18} y1={14} x2={width / 2 + 18 + half} y2={14} stroke={color} strokeWidth={2} strokeLinecap="round" />
      <g transform={`translate(${width / 2} 14) scale(${0.4 + 0.6 * progress})`}>
        <path d="M0 -11 L11 0 L0 11 L-11 0 Z" fill={color} />
      </g>
    </svg>
  );
};

/** Bingkai sudut ornamen tipis untuk kartu/manuskrip. */
export const CornerFrame: React.FC<{w: number; h: number; color?: string; inset?: number; progress?: number}> = ({
  w,
  h,
  color = C.gold,
  inset = 14,
  progress = 1,
}) => {
  const L = 54 * progress;
  const corner = (x: number, y: number, sx: number, sy: number) => (
    <g transform={`translate(${x} ${y}) scale(${sx} ${sy})`} fill="none" stroke={color} strokeWidth={2.5} strokeLinecap="round">
      <path d={`M0 ${L} L0 0 L${L} 0`} />
      <path d={`M10 ${L * 0.55} L10 10 L${L * 0.55} 10`} strokeWidth={1.2} opacity={0.7} />
    </g>
  );
  return (
    <svg width={w} height={h} style={{position: "absolute", inset: 0, pointerEvents: "none"}}>
      {corner(inset, inset, 1, 1)}
      {corner(w - inset, inset, -1, 1)}
      {corner(inset, h - inset, 1, -1)}
      {corner(w - inset, h - inset, -1, -1)}
    </svg>
  );
};

export const Chip: React.FC<{text: string; color?: string; bg?: string; size?: number; opacity?: number; style?: React.CSSProperties}> = ({
  text,
  color = C.goldLight,
  bg = "#06302acc",
  size = 30,
  opacity = 1,
  style,
}) => (
  <div
    style={{
      display: "inline-flex",
      alignItems: "center",
      padding: `${size * 0.35}px ${size * 0.8}px`,
      border: `2px solid ${color}`,
      borderRadius: 999,
      background: bg,
      color,
      fontFamily: "Inter, sans-serif",
      fontWeight: 600,
      fontSize: size,
      letterSpacing: 2,
      textTransform: "uppercase",
      opacity,
      whiteSpace: "nowrap",
      ...style,
    }}
  >
    {text}
  </div>
);
