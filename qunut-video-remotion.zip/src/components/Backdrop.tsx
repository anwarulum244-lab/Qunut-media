import React from "react";
import {AbsoluteFill, interpolateColors, random} from "remotion";
import {C, H, W} from "../theme";
import {useT} from "../helpers/anim";
import {SCENE_START} from "../data/timeline";

/** Warna cahaya aksen per adegan (halus, bergeser mengikuti narasi). */
const accentAt = (t: number) => {
  const s = SCENE_START;
  const stops = [0, s.B, s.C, s.D, s.E, s.F, s.G, s.H, 152.6];
  const cols = [C.copper, C.emeraldLight, C.gold, C.teal, C.copper, C.gold, C.emeraldLight, C.gold, C.gold];
  return interpolateColors(t, stops, cols);
};

const STAR_D =
  "M60 6 L72 34 L100 20 L86 48 L114 60 L86 72 L100 100 L72 86 L60 114 L48 86 L20 100 L34 72 L6 60 L34 48 L20 20 L48 34 Z";

const Particles: React.FC<{t: number; count: number}> = ({t, count}) => (
  <>
    {Array.from({length: count}).map((_, i) => {
      const x0 = random(`px${i}`) * W;
      const y0 = random(`py${i}`) * H;
      const sp = 8 + random(`ps${i}`) * 26;
      const amp = 10 + random(`pa${i}`) * 40;
      const size = 1.5 + random(`pz${i}`) * 3.5;
      const y = (((y0 - t * sp) % H) + H) % H;
      const x = x0 + Math.sin(t * (0.3 + random(`pf${i}`) * 0.6) + i) * amp;
      const tw = 0.25 + 0.55 * Math.abs(Math.sin(t * (0.6 + random(`pt${i}`)) + i * 1.7));
      return (
        <div
          key={i}
          style={{
            position: "absolute",
            left: x,
            top: y,
            width: size,
            height: size,
            borderRadius: "50%",
            background: C.goldLight,
            opacity: tw * 0.7,
            boxShadow: `0 0 ${size * 4}px ${C.gold}`,
          }}
        />
      );
    })}
  </>
);

export const Backdrop: React.FC = () => {
  const t = useT();
  const accent = accentAt(t);
  const drift = (t * 7) % 120;
  return (
    <AbsoluteFill style={{background: C.ink, overflow: "hidden"}}>
      <AbsoluteFill
        style={{
          background: `radial-gradient(ellipse 120% 70% at 50% 0%, ${C.emerald}cc 0%, ${C.emeraldDeep} 38%, ${C.night} 70%, ${C.ink} 100%)`,
        }}
      />
      <AbsoluteFill
        style={{
          background: `radial-gradient(circle at ${50 + Math.sin(t * 0.12) * 18}% ${62 + Math.cos(t * 0.1) * 8}%, ${accent}40 0%, transparent 52%)`,
          mixBlendMode: "screen",
        }}
      />
      {/* Pola geometris Islam (bintang 8 titik) berparalaks */}
      <svg width={W} height={H} style={{position: "absolute", inset: 0, opacity: 0.1}}>
        <defs>
          <pattern id="star8" width="120" height="120" patternUnits="userSpaceOnUse" patternTransform={`translate(${drift} ${-drift * 0.6}) scale(1.35)`}>
            <path d={STAR_D} fill="none" stroke={C.gold} strokeWidth="1.2" />
            <circle cx="60" cy="60" r="10" fill="none" stroke={C.gold} strokeWidth="0.8" />
          </pattern>
        </defs>
        <rect width={W} height={H} fill="url(#star8)" />
      </svg>
      {/* Berkas cahaya volumetrik */}
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            left: 120 + i * 340 + Math.sin(t * 0.15 + i) * 60,
            top: -200,
            width: 190,
            height: 2300,
            transform: `rotate(${16 + Math.sin(t * 0.1 + i) * 4}deg)`,
            transformOrigin: "top center",
            background: `linear-gradient(180deg, ${C.goldLight}33 0%, ${C.goldLight}00 75%)`,
            filter: "blur(30px)",
            opacity: 0.45 + 0.2 * Math.sin(t * 0.3 + i * 2),
            mixBlendMode: "screen",
          }}
        />
      ))}
      <Particles t={t} count={46} />
      {/* Tekstur kertas (butiran halus) */}
      <svg width={W} height={H} viewBox="0 0 540 960" preserveAspectRatio="none" style={{position: "absolute", inset: 0, opacity: 0.1, mixBlendMode: "overlay"}}>
        <filter id="paperGrain">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="3" seed="4" />
          <feColorMatrix values="0 0 0 0 1  0 0 0 0 0.95  0 0 0 0 0.8  0 0 0 1.1 -0.2" />
        </filter>
        <rect width="540" height="960" filter="url(#paperGrain)" />
      </svg>
      <AbsoluteFill style={{background: "radial-gradient(ellipse 90% 80% at 50% 50%, transparent 55%, #000000aa 100%)"}} />
    </AbsoluteFill>
  );
};
