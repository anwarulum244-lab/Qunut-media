import React from "react";
import {C} from "../theme";

const arch = (x: number, y: number, w: number, h: number) =>
  `M ${x} ${y + h} L ${x} ${y + w / 2} A ${w / 2} ${w / 2} 0 0 1 ${x + w} ${y + w / 2} L ${x + w} ${y + h} Z`;

const dome = (cx: number, y: number, r: number) => `M ${cx - r} ${y} A ${r} ${r} 0 0 1 ${cx + r} ${y} Z`;

const Minaret: React.FC<{cx: number; top: number; base: number; w: number; rim: string}> = ({cx, top, base, w, rim}) => {
  const bal = top + (base - top) * 0.42;
  return (
    <g>
      <rect x={cx - w / 2} y={bal} width={w} height={base - bal} />
      <rect x={cx - w * 0.78} y={bal - 10} width={w * 1.56} height={14} />
      <rect x={cx - w * 0.36} y={top + 52} width={w * 0.72} height={bal - top - 52} />
      <path d={`M ${cx - w * 0.5} ${top + 56} L ${cx} ${top} L ${cx + w * 0.5} ${top + 56} Z`} stroke={rim} strokeWidth={1.4} />
      <circle cx={cx} cy={top - 6} r={4.5} />
      <path d={`M ${cx} ${top - 34} m 0 0 a 11 11 0 1 0 8 -16 a 8.5 8.5 0 1 1 -8 16 Z`} fill={rim} stroke="none" opacity={0.9} />
    </g>
  );
};

/**
 * Siluet masjid (SVG). variant 1 = kubah besar + dua menara; variant 2 = kubah sedang + satu menara ramping.
 * glow = warna cahaya jendela/pinggir kubah.
 */
export const Mosque: React.FC<{variant: 1 | 2 | 3; glow: string; width?: number; lit?: number; id?: string}> = ({
  variant,
  glow,
  width = 600,
  lit = 1,
  id = "m",
}) => {
  const body = `url(#${id}-body)`;
  const wins: [number, number, number, number][] =
    variant === 1
      ? [[150, 520, 34, 90], [210, 520, 34, 90], [266, 500, 68, 130], [366, 520, 34, 90], [416, 520, 34, 90]]
      : variant === 2
        ? [[90, 540, 32, 85], [150, 540, 32, 85], [215, 515, 62, 125], [305, 540, 32, 85], [360, 540, 32, 85]]
        : [[110, 535, 30, 80], [170, 520, 40, 100], [250, 505, 100, 135], [380, 520, 40, 100], [440, 535, 30, 80]];
  return (
    <svg width={width} height={width * (700 / 600)} viewBox="0 0 600 700" style={{overflow: "visible"}}>
      <defs>
        <linearGradient id={`${id}-body`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0c2f2c" />
          <stop offset="1" stopColor="#020a09" />
        </linearGradient>
        <linearGradient id={`${id}-ground`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#010504" stopOpacity="0" />
          <stop offset="0.25" stopColor="#010504" stopOpacity="1" />
          <stop offset="0.75" stopColor="#010504" stopOpacity="1" />
          <stop offset="1" stopColor="#010504" stopOpacity="0" />
        </linearGradient>
        <filter id={`${id}-blur`}>
          <feGaussianBlur stdDeviation="9" />
        </filter>
      </defs>
      <g fill={body} stroke={glow} strokeWidth={1.8} strokeOpacity={0.7 * lit}>
        {variant === 1 && (
          <>
            <rect x={130} y={420} width={340} height={230} />
            <rect x={228} y={372} width={144} height={52} />
            <path d={dome(300, 372, 112)} />
            <path d={dome(190, 420, 46)} />
            <path d={dome(410, 420, 46)} />
            <rect x={296} y={226} width={8} height={30} stroke="none" />
            <Minaret cx={72} top={110} base={650} w={36} rim={glow} />
            <Minaret cx={528} top={110} base={650} w={36} rim={glow} />
          </>
        )}
        {variant === 2 && (
          <>
            <rect x={60} y={480} width={360} height={170} />
            <rect x={190} y={420} width={100} height={64} />
            <path d={dome(240, 420, 92)} />
            <path d={dome(110, 480, 40)} />
            <path d={dome(370, 480, 40)} />
            <Minaret cx={498} top={70} base={650} w={30} rim={glow} />
          </>
        )}
        {variant === 3 && (
          <>
            <rect x={90} y={470} width={420} height={180} />
            <rect x={210} y={400} width={180} height={74} />
            <path d={`M 190 400 C 190 300, 270 290, 300 230 C 330 290, 410 300, 410 400 Z`} />
            <path d={dome(130, 470, 36)} />
            <path d={dome(470, 470, 36)} />
            <Minaret cx={50} top={170} base={650} w={28} rim={glow} />
            <Minaret cx={550} top={170} base={650} w={28} rim={glow} />
          </>
        )}
      </g>
      {/* Jendela lengkung bercahaya */}
      <g filter={`url(#${id}-blur)`} fill={glow} opacity={0.75 * lit}>
        {wins.map((w, i) => (
          <path key={i} d={arch(w[0], w[1], w[2], w[3])} />
        ))}
      </g>
      <g fill={C.goldLight} opacity={0.95 * lit}>
        {wins.map((w, i) => (
          <path key={i} d={arch(w[0] + 3, w[1] + 3, w[2] - 6, w[3] - 3)} />
        ))}
      </g>
      <rect x={-260} y={648} width={1120} height={52} fill={`url(#${id}-ground)`} />
    </svg>
  );
};
