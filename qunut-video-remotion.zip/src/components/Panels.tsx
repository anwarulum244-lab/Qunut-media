import React from "react";
import {C} from "../theme";
import {CornerFrame} from "./Ornaments";

/** Kartu manuskrip/perkamen untuk teks hadis. reveal 0..1 membuka dari tengah. */
export const Manuscript: React.FC<{
  width: number;
  height: number;
  reveal?: number;
  children?: React.ReactNode;
  tint?: string;
  style?: React.CSSProperties;
  label?: string;
}> = ({width, height, reveal = 1, children, tint = C.parchment, style, label}) => {
  const inset = (1 - reveal) * 50;
  return (
    <div
      style={{
        position: "relative",
        width,
        height,
        borderRadius: 18,
        background: `radial-gradient(ellipse at 30% 20%, #fff7de 0%, ${tint} 45%, ${C.parchmentDark} 100%)`,
        boxShadow: `0 40px 90px #000c, inset 0 0 90px #8f6a2255, 0 0 0 3px ${C.goldDeep}`,
        clipPath: `inset(${inset}% 0% ${inset}% 0% round 18px)`,
        opacity: Math.min(1, reveal * 2),
        overflow: "hidden",
        ...style,
      }}
    >
      <svg width={width} height={height} viewBox={`0 0 ${width / 2} ${height / 2}`} preserveAspectRatio="none" style={{position: "absolute", inset: 0, opacity: 0.35, mixBlendMode: "multiply"}}>
        <filter id={`ms-${width}-${height}`}>
          <feTurbulence type="fractalNoise" baseFrequency="0.55" numOctaves="3" seed="9" />
          <feColorMatrix values="0 0 0 0 0.4  0 0 0 0 0.3  0 0 0 0 0.15  0 0 0 0.9 -0.15" />
        </filter>
        <rect width={width / 2} height={height / 2} filter={`url(#ms-${width}-${height})`} />
      </svg>
      <div style={{position: "absolute", inset: 18, border: `2px solid ${C.goldDeep}88`, borderRadius: 10}} />
      <CornerFrame w={width} h={height} color={C.goldDeep} inset={26} progress={reveal} />
      {label && (
        <div
          style={{
            position: "absolute",
            top: 40,
            left: 0,
            right: 0,
            textAlign: "center",
            fontFamily: "Inter, sans-serif",
            fontWeight: 600,
            fontSize: 24,
            letterSpacing: 7,
            textTransform: "uppercase",
            color: C.goldDeep,
          }}
        >
          {label}
        </div>
      )}
      <div style={{position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center"}}>{children}</div>
    </div>
  );
};

/** Panel kaca gelap bergaris emas. */
export const Glass: React.FC<{
  width: number;
  height: number;
  children?: React.ReactNode;
  color?: string;
  style?: React.CSSProperties;
  glow?: number;
}> = ({width, height, children, color = C.gold, style, glow = 0}) => (
  <div
    style={{
      position: "relative",
      width,
      height,
      borderRadius: 26,
      background: "linear-gradient(160deg, #0b3a31dd 0%, #061f1fe6 100%)",
      border: `2.5px solid ${color}`,
      boxShadow: `0 30px 80px #000b, 0 0 ${60 * glow}px ${color}88, inset 0 0 60px #00000066`,
      ...style,
    }}
  >
    <CornerFrame w={width} h={height} color={color} inset={12} />
    {children}
  </div>
);
