import React from "react";
import {C, FONT} from "../theme";
import {easeInOut, easeOut, seg, useT} from "../helpers/anim";
import {blendPose, POSES, PrayerFigure} from "./PrayerFigure";

export type QunutMode = "syafii" | "maliki";

/**
 * Urutan gerak shalat Subuh rakaat ke-2 dengan posisi qunut yang BERBEDA menurut mazhab:
 *  - Syafi'i: SETELAH bangkit dari rukuk (i'tidal)
 *  - Maliki : SEBELUM rukuk (saat berdiri)
 * Satu komponen dipakai untuk keduanya agar posisi tidak mungkin tertukar.
 */
export const stageOfQunut = (mode: QunutMode) => (mode === "syafii" ? 2 : 0);

const STAGES = ["Berdiri", "Rukuk", "I'tidal", "Sujud"];

export const poseAt = (mode: QunutMode, t: number) => {
  if (mode === "syafii") {
    const k1 = seg(t, 17.55, 18.05, easeInOut);
    const k2 = seg(t, 18.25, 18.85, easeInOut);
    const p1 = blendPose(POSES.qiyam, POSES.rukuk, k1);
    const pose = blendPose(p1, POSES.itidal, k2);
    const stage = t < 17.55 ? 0 : t < 18.3 ? 1 : 2;
    const raise = seg(t, 18.94, 19.45, easeOut);
    return {pose, raise, stage, qunutOn: t >= 18.94};
  }
  const k = seg(t, 124.45, 125.1, easeInOut);
  const pose = blendPose(POSES.qiyam, POSES.rukuk, k);
  const raise = seg(t, 121.8, 122.3, easeOut) * (1 - seg(t, 124.2, 124.6, easeInOut));
  const stage = t < 124.5 ? 0 : 1;
  return {pose, raise, stage, qunutOn: t >= 121.8 && t < 124.6};
};

export const PrayerSequence: React.FC<{mode: QunutMode; figureSize?: number; showChips?: boolean; markerAt: number}> = ({
  mode,
  figureSize = 560,
  showChips = true,
  markerAt,
}) => {
  const t = useT();
  const {pose, raise, stage} = poseAt(mode, t);
  const qStage = stageOfQunut(mode);
  const chipW = 214;
  const gap = 14;
  const rowW = chipW * 4 + gap * 3;
  const mark = seg(t, markerAt, markerAt + 0.5, easeOut);
  return (
    <div style={{display: "flex", flexDirection: "column", alignItems: "center", width: rowW}}>
      <div style={{position: "relative", width: figureSize, height: figureSize}}>
        <PrayerFigure pose={pose} raise={raise} size={figureSize} glow={raise > 0.5} />
        {raise > 0.5 && (
          <div
            style={{
              position: "absolute",
              left: figureSize * 0.62,
              top: figureSize * 0.1,
              fontFamily: FONT.sans,
              fontWeight: 600,
              fontSize: 26,
              letterSpacing: 5,
              color: C.gold,
              opacity: mark,
              textTransform: "uppercase",
            }}
          >
            ◂ Qunut
          </div>
        )}
      </div>
      {showChips && (
        <div style={{position: "relative", width: rowW, marginTop: 20}}>
          {/* penanda qunut menempel pada tahap yang benar */}
          <div
            style={{
              position: "absolute",
              left: qStage * (chipW + gap),
              top: -48,
              width: chipW,
              textAlign: "center",
              opacity: mark,
              transform: `translateY(${(1 - mark) * 14}px)`,
            }}
          >
            <div
              style={{
                display: "inline-block",
                padding: "6px 22px",
                borderRadius: 999,
                background: C.gold,
                color: C.ink,
                fontFamily: FONT.sans,
                fontWeight: 600,
                fontSize: 24,
                letterSpacing: 4,
                textTransform: "uppercase",
              }}
            >
              Qunut
            </div>
          </div>
          <div style={{display: "flex", gap}}>
            {STAGES.map((s, i) => {
              const active = i === stage;
              const isQ = i === qStage && mark > 0.1;
              return (
                <div
                  key={s}
                  style={{
                    width: chipW,
                    height: 84,
                    borderRadius: 18,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontFamily: FONT.serif,
                    fontWeight: 700,
                    fontSize: 38,
                    color: active ? C.ink : C.ivory,
                    background: active ? C.goldLight : "#06302acc",
                    border: `2.5px solid ${isQ ? C.gold : "#d9a44166"}`,
                    boxShadow: isQ ? `0 0 34px ${C.gold}99` : "none",
                    opacity: active || isQ ? 1 : 0.62,
                  }}
                >
                  {s}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
