import React from "react";
import {C, FONT} from "../theme";
import {clamp, easeOut, easeSoft, seg, springAt, useT} from "../helpers/anim";
import {GoldDivider} from "./Ornaments";
import type {TimedWord} from "../data/timeline";

/** Teks Arab RTL yang muncul kata demi kata (kanan → kiri) mengikuti waktu bacaan. */
export type ArabicHighlight = {i0: number; i1: number; t0: number; t1: number; color: string};

export const ArabicLine: React.FC<{
  words: string[];
  times: number[];
  size: number;
  width: number;
  color?: string;
  activeColor?: string;
  highlights?: ArabicHighlight[];
  lineHeight?: number;
  gap?: number;
  opacity?: number;
  glow?: string;
  justify?: "center" | "flex-start";
}> = ({words, times, size, width, color = C.ivory, activeColor = C.goldLight, highlights = [], lineHeight = 1.7, gap, opacity = 1, glow, justify = "center"}) => {
  const t = useT();
  return (
    <div
      dir="rtl"
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: justify,
        width,
        columnGap: gap ?? size * 0.28,
        rowGap: 0,
        fontFamily: FONT.arabic,
        fontSize: size,
        lineHeight,
        opacity,
        direction: "rtl",
      }}
    >
      {words.map((w, i) => {
        const p = seg(t, times[i], times[i] + 0.5, easeOut);
        const next = times[i + 1] ?? times[i] + 1.2;
        const active = t >= times[i] && t < next;
        const hl = highlights.find((h) => i >= h.i0 && i <= h.i1 && t >= h.t0 && t <= h.t1 + 0.6);
        const hlP = hl ? seg(t, hl.t0, hl.t0 + 0.4, easeOut) * (1 - seg(t, hl.t1, hl.t1 + 0.6)) : 0;
        const col = hl && hlP > 0.01 ? hl.color : active ? activeColor : color;
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: p,
              transform: `translate(${(1 - p) * 46}px, ${(1 - p) * 16}px) scale(${1 + hlP * 0.07})`,
              filter: p < 1 ? `blur(${(1 - p) * 7}px)` : undefined,
              color: col,
              textShadow: hlP > 0.01 ? `0 0 ${26 * hlP}px ${hl?.color}` : active && glow ? `0 0 22px ${glow}` : undefined,
              fontWeight: 400,
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

/** Terjemahan: tiap kata muncul pada saat kata itu diucapkan. */
export const TimedText: React.FC<{
  words: TimedWord[];
  size: number;
  width: number;
  color?: string;
  activeColor?: string;
  italic?: boolean;
  align?: "center" | "left";
  weight?: number;
  lineHeight?: number;
  fontFamily?: string;
}> = ({words, size, width, color = C.ivory, activeColor = C.goldLight, italic = false, align = "center", weight = 600, lineHeight = 1.28, fontFamily = FONT.serif}) => {
  const t = useT();
  return (
    <div
      style={{
        width,
        display: "flex",
        flexWrap: "wrap",
        justifyContent: align === "center" ? "center" : "flex-start",
        columnGap: size * 0.26,
        fontFamily,
        fontSize: size,
        fontWeight: weight,
        fontStyle: italic ? "italic" : "normal",
        lineHeight,
      }}
    >
      {words.map(([w, at], i) => {
        const p = seg(t, at - 0.04, at + 0.28, easeOut);
        const next = words[i + 1]?.[1] ?? at + 1;
        const active = t >= at && t < next;
        return (
          <span
            key={i}
            style={{
              opacity: p,
              transform: `translateY(${(1 - p) * 14}px)`,
              filter: p < 1 ? `blur(${(1 - p) * 4}px)` : undefined,
              color: active ? activeColor : color,
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

export type KWord = {text: string; at: number; color?: string; size?: number; italic?: boolean; weight?: number; breakAfter?: boolean};

/** Tipografi kinetik: tiap kata masuk dengan spring (berbobot) pada waktu ucapnya. */
export const KineticWords: React.FC<{
  words: KWord[];
  size: number;
  width: number;
  color?: string;
  family?: string;
  opacity?: number;
  upper?: boolean;
  letterSpacing?: number;
  lineHeight?: number;
  from?: "below" | "above" | "scale";
}> = ({words, size, width, color = C.ivory, family = FONT.serif, opacity = 1, upper = false, letterSpacing = 0, lineHeight = 1.05, from = "below"}) => {
  const t = useT();
  return (
    <div
      style={{
        width,
        display: "flex",
        flexWrap: "wrap",
        justifyContent: "center",
        alignItems: "baseline",
        columnGap: size * 0.24,
        fontFamily: family,
        textTransform: upper ? "uppercase" : "none",
        letterSpacing,
        lineHeight,
        opacity,
      }}
    >
      {words.map((w, i) => {
        const s = springAt(t, w.at, {damping: 13, stiffness: 140, mass: 0.7});
        const o = clamp(s * 2.2);
        const y = from === "above" ? -(1 - s) * 70 : (1 - s) * 70;
        const sc = from === "scale" ? 0.4 + 0.6 * s : 0.85 + 0.15 * s;
        return (
          <React.Fragment key={i}>
            <span
              style={{
                display: "inline-block",
                fontSize: w.size ?? size,
                fontWeight: w.weight ?? 600,
                fontStyle: w.italic ? "italic" : "normal",
                color: w.color ?? color,
                opacity: o,
                transform: `translateY(${y}px) scale(${sc})`,
                filter: s < 0.95 ? `blur(${(1 - s) * 10}px)` : undefined,
                textShadow: (w.color ?? color) === C.inkBrown || (w.color ?? color) === C.copper ? undefined : `0 6px 30px #000a`,
              }}
            >
              {w.text}
            </span>
            {w.breakAfter && <div style={{flexBasis: "100%", height: 0}} />}
          </React.Fragment>
        );
      })}
    </div>
  );
};

/** Judul editorial: kicker huruf kapital + judul serif besar + garis emas. */
export const EditorialTitle: React.FC<{
  kicker: string;
  title: string;
  at: number;
  width: number;
  size?: number;
  color?: string;
  accent?: string;
  exitAt?: number;
}> = ({kicker, title, at, width, size = 118, color = C.ivory, accent = C.gold, exitAt}) => {
  const t = useT();
  const k = seg(t, at, at + 0.6, easeOut);
  const words = title.split(" ");
  const ex = exitAt ? seg(t, exitAt, exitAt + 0.5, easeSoft) : 0;
  return (
    <div style={{width, textAlign: "center", opacity: 1 - ex, transform: `translateY(${-ex * 40}px)`}}>
      <div
        style={{
          fontFamily: FONT.sans,
          fontWeight: 600,
          fontSize: 28,
          letterSpacing: 10 * k,
          color: accent,
          opacity: k,
          textTransform: "uppercase",
          marginBottom: 12,
        }}
      >
        {kicker}
      </div>
      <KineticWords
        words={words.map((w, i) => ({text: w, at: at + 0.2 + i * 0.16, weight: 700}))}
        size={size}
        width={width}
        color={color}
        lineHeight={1}
      />
      <div style={{display: "flex", justifyContent: "center", marginTop: 14}}>
        <GoldDivider width={Math.min(width, 640)} progress={seg(t, at + 0.5, at + 1.3, easeOut)} color={accent} />
      </div>
    </div>
  );
};
