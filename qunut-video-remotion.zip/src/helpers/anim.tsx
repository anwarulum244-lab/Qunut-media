import React, {createContext, useContext} from "react";
import {Easing, Sequence, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {FPS} from "../theme";

export const sec = (s: number) => Math.round(s * FPS);

export const easeOut = Easing.bezier(0.16, 1, 0.3, 1);
export const easeSoft = Easing.bezier(0.22, 1, 0.36, 1);
export const easeInOut = Easing.bezier(0.65, 0, 0.35, 1);
export const easeIn = Easing.bezier(0.55, 0, 1, 0.45);

export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, k: number) => a + (b - a) * k;

/** Progres 0..1 dari waktu t (detik) antara a dan b, dengan easing. */
export const seg = (t: number, a: number, b: number, ease: (x: number) => number = easeSoft) =>
  ease(clamp((t - a) / Math.max(1e-6, b - a)));

/** Naik di [a,b], turun di [c,d]. */
export const fadeIO = (t: number, a: number, b: number, c: number, d: number) =>
  seg(t, a, b, easeSoft) * (1 - seg(t, c, d, easeSoft));

/** Spring berbasis waktu absolut (detik). */
export const springAt = (
  t: number,
  start: number,
  config: {damping?: number; stiffness?: number; mass?: number} = {damping: 14, stiffness: 120, mass: 0.8},
) => {
  const frame = Math.max(0, (t - start) * FPS);
  return spring({frame, fps: FPS, config});
};

/** Jam adegan: memberi waktu absolut (detik) ke semua komponen di dalam Sequence. */
const ClockCtx = createContext<number>(0);

export const useT = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const offset = useContext(ClockCtx);
  return offset + frame / fps;
};

export const Scene: React.FC<{from: number; to: number; name: string; children: React.ReactNode}> = ({
  from,
  to,
  name,
  children,
}) => (
  <Sequence from={sec(from)} durationInFrames={Math.max(1, sec(to) - sec(from))} name={name} layout="none">
    <ClockCtx.Provider value={from}>{children}</ClockCtx.Provider>
  </Sequence>
);

/** Fade/slide keluar-masuk standar untuk blok di dalam adegan. */
export const useBlock = (a: number, b: number, c: number, d: number) => {
  const t = useT();
  const inP = seg(t, a, b, easeOut);
  const outP = seg(t, c, d, easeInOut);
  return {t, opacity: inP * (1 - outP), inP, outP};
};
