import React from "react";
import {Composition} from "remotion";
import {getAudioDurationInSeconds} from "@remotion/media-utils";
import {staticFile} from "remotion";
import {QunutVideo, QunutProps} from "./Composition";
import {AUDIO_DURATION_FALLBACK, TOTAL_FRAMES_FALLBACK, validateTimeline} from "./data/timeline";
import {FPS, H, W} from "./theme";

validateTimeline();

export const RemotionRoot: React.FC = () => (
  <Composition
    id="QunutFikih"
    component={QunutVideo}
    width={W}
    height={H}
    fps={FPS}
    durationInFrames={TOTAL_FRAMES_FALLBACK}
    defaultProps={{durationInSeconds: AUDIO_DURATION_FALLBACK} satisfies QunutProps}
    // Durasi video DIAMBIL dari file MP3 yang sebenarnya (bukan angka tebakan).
    calculateMetadata={async () => {
      let seconds = AUDIO_DURATION_FALLBACK;
      try {
        seconds = await getAudioDurationInSeconds(staticFile("qunut_edit.mp3"));
      } catch (e) {
        console.warn("Gagal membaca durasi MP3, memakai nilai hasil ffprobe:", e);
      }
      return {durationInFrames: Math.ceil(seconds * FPS), props: {durationInSeconds: seconds}};
    }}
  />
);
