export const FPS = 30;
export const W = 1080;
export const H = 1920;

/** Palet: hijau zamrud gelap, hitam kebiruan, emas hangat, putih gading, tembaga. */
export const C = {
  ink: "#04100f",
  night: "#071b1d",
  emeraldDeep: "#06302a",
  emerald: "#0d5a47",
  emeraldLight: "#1f8f70",
  gold: "#d9a441",
  goldLight: "#f2d58f",
  goldDeep: "#8f6a22",
  ivory: "#f6efdc",
  parchment: "#efe3c2",
  parchmentDark: "#d3bf8a",
  copper: "#c0714a",
  copperLight: "#e29a74",
  inkBrown: "#2a1b0e",
  teal: "#2c8a90",
};

export const FONT = {
  arabic: "Amiri, 'Noto Naskh Arabic', 'Traditional Arabic', serif",
  serif: "'Cormorant Garamond', Georgia, serif",
  sans: "Inter, system-ui, sans-serif",
};

/** Area aman untuk HP / UI Reels-TikTok. */
export const SAFE = {x: 96, top: 170, bottom: 300};
