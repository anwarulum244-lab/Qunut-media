import {continueRender, delayRender, staticFile} from "remotion";

type Face = {family: string; file: string; weight: string; style?: string};

const FACES: Face[] = [
  {family: "Amiri", file: "amiri-arabic-400-normal.woff2", weight: "400"},
  {family: "Amiri", file: "amiri-arabic-700-normal.woff2", weight: "700"},
  {family: "Cormorant Garamond", file: "cormorant-garamond-latin-500-normal.woff2", weight: "500"},
  {family: "Cormorant Garamond", file: "cormorant-garamond-latin-600-normal.woff2", weight: "600"},
  {family: "Cormorant Garamond", file: "cormorant-garamond-latin-700-normal.woff2", weight: "700"},
  {family: "Cormorant Garamond", file: "cormorant-garamond-latin-500-italic.woff2", weight: "500", style: "italic"},
  {family: "Inter", file: "inter-latin-400-normal.woff2", weight: "400"},
  {family: "Inter", file: "inter-latin-600-normal.woff2", weight: "600"},
];

// Font dimuat dari public/fonts (offline, tidak bergantung jaringan saat render).
if (typeof document !== "undefined") {
  const handle = delayRender("Memuat font Arab & Latin");
  Promise.all(
    FACES.map(async (f) => {
      const face = new FontFace(f.family, `url(${staticFile("fonts/" + f.file)}) format("woff2")`, {
        weight: f.weight,
        style: f.style ?? "normal",
      });
      await face.load();
      (document.fonts as unknown as {add: (f: FontFace) => void}).add(face);
    }),
  )
    .then(() => continueRender(handle))
    .catch((err) => {
      console.error("Gagal memuat font", err);
      continueRender(handle);
    });
}
