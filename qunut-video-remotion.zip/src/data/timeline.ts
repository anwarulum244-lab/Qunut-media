/**
 * TIMELINE NARASI — sumber kebenaran sinkronisasi.
 * Semua angka dalam DETIK pada audio asli `public/qunut_edit.mp3` (152,592 dtk).
 * Timestamp diperoleh dari transkripsi otomatis berpenanda waktu per kata (lihat docs/transkrip-whisper.json),
 * lalu diperiksa ulang terhadap isi kalimat. Teks di bawah adalah teks narasi yang DIRAPIKAN ejaannya
 * (mis. "kunut" → "qunut") hanya untuk dokumentasi; teks ini tidak ditampilkan sebagai narasi sintetis.
 */
export type NarrationSegment = {
  start: number;
  end: number;
  text: string;
  scene: SceneId;
  visualCue: string;
};

export type SceneId = "A" | "B" | "C" | "D" | "E" | "F" | "G" | "H";

export const NARRATION: NarrationSegment[] = [
  {start: 0.0, end: 5.0, text: "Kenapa di sebagian masjid, imam membaca qunut seusai shalat Subuh, sedangkan di masjid lain tidak?", scene: "A", visualCue: "Layar gelap → dua masjid terungkap; kamera bergeser dari masjid dengan qunut ke masjid tanpa qunut"},
  {start: 5.68, end: 7.0, text: "Apakah salah satunya keliru?", scene: "A", visualCue: "Kinetic typography pertanyaan, kamera mundur menampilkan kedua masjid"},
  {start: 7.4, end: 8.8, text: "Jawabannya tidak.", scene: "A", visualCue: "Impact + shock ring emas, pertanyaan runtuh menjadi 'TIDAK'"},
  {start: 9.1, end: 12.52, text: "Ini perbedaan pendapat antar ulama, dan masing-masing punya dalil.", scene: "A", visualCue: "Dua garis cahaya dari dua masjid bertemu di gulungan 'Dalil'"},
  {start: 12.98, end: 19.18, text: "Menurut Mazhab Syafi'i, qunut Subuh hukumnya sunnah, dibaca di rakaat kedua, setelah bangkit dari rukuk.", scene: "B", visualCue: "Judul mazhab; urutan shalat berdiri → rukuk → i'tidal; penanda qunut di i'tidal rakaat ke-2"},
  {start: 19.62, end: 25.3, text: "Dalil utamanya, hadis Anas bin Malik, radhiyallahu 'anhu, diriwayatkan Imam Ahmad dan Daruquthni.", scene: "B", visualCue: "Fokus pindah ke lembar manuskrip hadis Anas"},
  {start: 25.3, end: 32.02, text: "[Pembacaan hadis Arab] Maa zaala Rasulullah ﷺ yaqnutu fil-fajri hatta faaraqad-dunya.", scene: "B", visualCue: "Teks Arab muncul kata demi kata kanan→kiri mengikuti bacaan"},
  {start: 32.1, end: 36.88, text: "Artinya, Rasulullah terus berqunut pada shalat Subuh sampai beliau wafat.", scene: "B", visualCue: "Terjemahan muncul kata demi kata"},
  {start: 37.18, end: 41.36, text: "Derajat hadis ini diperselisihkan ulama, tetapi dipegang oleh Syafi'iyah.", scene: "B", visualCue: "Dua lembar kajian berbeda; benang emas ke penanda Syafi'iyah"},
  {start: 41.72, end: 44.32, text: "Bagaimana dengan hadis bahwa Nabi meninggalkan qunut?", scene: "C", visualCue: "Manuskrip terbuka; pertanyaan kinetik"},
  {start: 44.68, end: 47.3, text: "Dalam riwayat Bukhari dan Muslim, Anas berkata,", scene: "C", visualCue: "Kartu referensi Sahih al-Bukhari & Sahih Muslim"},
  {start: 47.74, end: 54.74, text: "[Pembacaan hadis Arab] Qanata Rasulullah ﷺ syahran yad'u 'ala Ri'lin wa Dzakwan, tsumma tarakahu.", scene: "C", visualCue: "Teks Arab bertahap; frasa ثُمَّ تَرَكَهُ disorot"},
  {start: 55.06, end: 63.1, text: "Artinya, Rasulullah berqunut selama satu bulan, mendoakan keburukan atas kabilah Ri'l dan Dzakwan, kemudian beliau meninggalkannya.", scene: "C", visualCue: "Terjemahan bertahap; frasa Arab yang sepadan ikut menyala"},
  {start: 63.5, end: 69.3, text: "Syafi'iyah memahami bahwa yang ditinggalkan adalah doa laknat atas kabilah itu, bukan qunut Subuh.", scene: "C", visualCue: "Diagram dua lapisan interpretasi (menurut Syafi'iyah)"},
  {start: 69.66, end: 73.44, text: "Adapun Mazhab Hanafi dan Hanbali, qunut Subuh tidak disunnahkan.", scene: "D", visualCue: "Dua panel komparatif setara"},
  {start: 73.78, end: 77.4, text: "Qunut hanya dilakukan pada shalat witir dan saat terjadi musibah.", scene: "D", visualCue: "Dua penanda: Witir & Musibah"},
  {start: 77.4, end: 85.7, text: "Dalil mereka adalah hadis Sa'ad bin Thariq al-Asyja'i, diriwayatkan Tirmidzi, Nasa'i, dan Ibnu Majah.", scene: "D", visualCue: "Kamera menyamping ke manuskrip periwayatan"},
  {start: 85.7, end: 86.7, text: "Ia bertanya kepada ayahnya, 'Wahai ayah,'", scene: "D", visualCue: "Dialog periwayatan (tipografi)"},
  {start: 87.14, end: 99.58, text: "[Pembacaan hadis Arab] Innaka qad shallaita khalfa Rasulillah ﷺ wa Abi Bakrin wa 'Umara wa 'Utsmana wa 'Aliyyin hahuna bil-Kufah, akanu yaqnutun? qala: ayy bunayya, muhdats.", scene: "D", visualCue: "Dialog Arab bertahap per frasa"},
  {start: 99.88, end: 112.0, text: "Artinya, 'Wahai ayah, engkau pernah shalat di belakang Rasulullah, Abu Bakar, Umar, Utsman dan Ali di Kufah ini, apakah mereka berqunut?' Ia menjawab, 'Wahai anakku, itu perkara baru.'", scene: "D", visualCue: "Terjemahan dialog bertahap"},
  {start: 112.48, end: 119.2, text: "Mereka juga berdalil dengan hadis Anas dalam Bukhari dan Muslim tadi, bahwa Nabi hanya berqunut sebulan lalu meninggalkannya.", scene: "D", visualCue: "Garis waktu 'satu bulan → ditinggalkan' (menurut Hanafi & Hanbali)"},
  {start: 119.66, end: 125.18, text: "Sementara Mazhab Maliki menganggap qunut Subuh mustahab dibaca sebelum rukuk dengan suara pelan.", scene: "E", visualCue: "Urutan shalat: qunut di berdiri SEBELUM rukuk; indikator suara pelan"},
  {start: 125.18, end: 127.54, text: "Jadi perbedaannya ada pada dua hal.", scene: "F", visualCue: "Angka I & II"},
  {start: 127.8, end: 132.46, text: "Derajat hadis Anas yang pertama, dan makna riwayat bahwa Nabi meninggalkan qunut.", scene: "F", visualCue: "Dua cabang diagram → empat mazhab seimbang"},
  {start: 132.74, end: 135.86, text: "Pembahasannya bisa kamu baca di kitab Al-Umm dan Al-Majmu'", scene: "G", visualCue: "Kitab Al-Umm lalu Al-Majmu' disorot"},
  {start: 135.86, end: 141.44, text: "untuk mazhab Syafi'i, Al-Hidayah untuk mazhab Hanafi, dan Al-Mughni untuk mazhab Hanbali.", scene: "G", visualCue: "Al-Hidayah lalu Al-Mughni disorot"},
  {start: 141.78, end: 145.06, text: "Perbedaan seperti ini mengajarkan kita untuk saling menghormati.", scene: "H", visualCue: "Elemen semua adegan menyatu; masjid damai"},
  {start: 145.44, end: 148.38, text: "Menurut kamu, apa hikmahnya? Tulis di kolom komentar.", scene: "H", visualCue: "Elemen kolom komentar minimalis"},
  {start: 148.8, end: 152.54, text: "Dan kalau ada topik fikih yang ingin dibahas berikutnya, sebutkan juga ya.", scene: "H", visualCue: "Ajakan topik berikutnya; penutup elegan"},
];

/** Batas adegan (detik). Dipilih di tengah jeda antarkalimat. Akhir adegan H = durasi audio sebenarnya. */
export const SCENE_START: Record<SceneId, number> = {
  A: 0,
  B: 12.8,
  C: 41.55,
  D: 69.48,
  E: 119.43,
  F: 125.15,
  G: 132.6,
  H: 141.6,
};

export const AUDIO_DURATION_FALLBACK = 152.592; // hasil ffprobe pada qunut_edit.mp3
export const TOTAL_FRAMES_FALLBACK = Math.ceil(AUDIO_DURATION_FALLBACK * 30); // 4578

/** Jendela pembacaan Arab: musik diturunkan, SFX dihindari. */
export const RECITATION_WINDOWS: [number, number][] = [
  [25.3, 32.05],
  [47.7, 54.8],
  [86.2, 99.7],
];

/** Kata-kata Arab + waktu mulai tiap kata (detik absolut), diselaraskan ke bacaan pada MP3. */
export const HADITH_ANAS_QUNUT = {
  words: ["مَا", "زَالَ", "رَسُولُ", "اللَّهِ", "ﷺ", "يَقْنُتُ", "فِي", "الْفَجْرِ", "حَتَّى", "فَارَقَ", "الدُّنْيَا"],
  times: [25.3, 25.8, 26.3, 26.75, 27.1, 28.86, 29.58, 29.74, 30.22, 30.86, 31.48],
};

export const HADITH_TINGGAL = {
  words: ["قَنَتَ", "رَسُولُ", "اللَّهِ", "ﷺ", "شَهْرًا", "يَدْعُو", "عَلَى", "رِعْلٍ", "وَذَكْوَانَ،", "ثُمَّ", "تَرَكَهُ"],
  times: [47.74, 48.04, 48.5, 48.86, 50.68, 51.3, 51.94, 52.28, 52.78, 53.84, 54.26],
};

export const HADITH_SAAD = {
  lines: [
    {words: ["يَا", "أَبَتِ،"], times: [86.22, 86.42]},
    {words: ["إِنَّكَ", "قَدْ", "صَلَّيْتَ", "خَلْفَ", "رَسُولِ", "اللَّهِ", "ﷺ"], times: [87.14, 87.4, 87.72, 88.34, 88.68, 89.0, 89.36]},
    {words: ["وَأَبِي", "بَكْرٍ", "وَعُمَرَ", "وَعُثْمَانَ", "وَعَلِيٍّ", "هَاهُنَا", "بِالْكُوفَةِ،"], times: [91.48, 91.78, 92.42, 93.04, 93.82, 94.52, 94.88]},
    {words: ["أَكَانُوا", "يَقْنُتُونَ؟"], times: [95.92, 96.36]},
    {words: ["قَالَ:", "أَيْ", "بُنَيَّ،", "مُحْدَثٌ"], times: [97.46, 97.78, 98.32, 99.04]},
  ],
};

export type TimedWord = [string, number];

export const TR_ANAS_QUNUT: TimedWord[] = [
  ["Rasulullah", 33.24], ["terus", 33.86], ["berqunut", 34.08], ["pada", 34.66], ["shalat", 34.88],
  ["Subuh", 35.18], ["sampai", 35.6], ["beliau", 35.98], ["wafat.", 36.3],
];

export const TR_TINGGAL: TimedWord[] = [
  ["Rasulullah", 55.94], ["berqunut", 56.52], ["selama", 57.06], ["satu", 57.38], ["bulan,", 57.62],
  ["mendoakan", 58.18], ["keburukan", 58.82], ["atas", 59.42], ["kabilah", 59.76], ["Ri'l", 60.18],
  ["dan", 60.44], ["Dzakwan,", 60.72], ["kemudian", 61.56], ["beliau", 61.98], ["meninggalkannya.", 62.38],
];

export const TR_SAAD: {line: TimedWord[]}[] = [
  {line: [["Wahai", 100.8], ["ayah,", 101.1]]},
  {line: [["Engkau", 101.5], ["pernah", 102.06], ["shalat", 102.28], ["di", 102.7], ["belakang", 102.84], ["Rasulullah,", 103.1], ["Abu", 103.7], ["Bakar,", 103.85], ["Umar,", 105.0], ["Utsman", 105.66], ["dan", 106.0], ["Ali", 106.18], ["di", 106.56], ["Kufah", 106.74], ["ini,", 106.98]]},
  {line: [["apakah", 107.56], ["mereka", 107.88], ["berqunut?", 108.12]]},
  {line: [["Ia", 109.06], ["menjawab:", 109.18], ["“Wahai", 109.94], ["anakku,", 110.2], ["itu", 110.98], ["perkara", 111.3], ["baru.”", 111.62]]},
];

/** Sanity check saat dev: urutan waktu harus naik. */
export const validateTimeline = () => {
  for (let i = 1; i < NARRATION.length; i++) {
    if (NARRATION[i].start < NARRATION[i - 1].start) throw new Error(`Timeline tidak urut di indeks ${i}`);
  }
};
