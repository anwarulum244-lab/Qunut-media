import React from "react";
import {AbsoluteFill} from "remotion";
import {C, FONT} from "../theme";
import {easeInOut, easeOut, easeSoft, lerp, seg, springAt, useT} from "../helpers/anim";
import {ArabicLine, EditorialTitle, KineticWords, TimedText} from "../components/Text";
import {Chip, GoldDivider, Star8} from "../components/Ornaments";
import {Manuscript} from "../components/Panels";
import {PrayerSequence} from "../components/PrayerSequence";
import {HADITH_ANAS_QUNUT, TR_ANAS_QUNUT} from "../data/timeline";

/** Lembar kajian bergaya berbeda (dua penilaian ulama) — netral, tanpa stempel sahih/palsu. */
const StudySheet: React.FC<{variant: 1 | 2; label: string; progress: number}> = ({variant, label, progress}) => {
  const col = variant === 1 ? C.goldDeep : C.copper;
  return (
    <div style={{width: 420, height: 560, position: "relative", transform: `rotate(${variant === 1 ? -3 : 3}deg)`}}>
      <Manuscript width={420} height={560} reveal={progress}>
        <svg width={420} height={560} style={{position: "absolute", inset: 0}}>
          {Array.from({length: 11}).map((_, i) => {
            const y = 150 + i * 34;
            const w = 250 + ((i * 53) % 90);
            return <line key={i} x1={370 - w} x2={370} y1={y} y2={y} stroke={C.inkBrown} strokeWidth={5} strokeLinecap="round" opacity={0.45} />;
          })}
          {variant === 1
            ? [0, 2, 3, 6, 8].map((i) => <path key={i} d={`M ${120 + i * 6} ${164 + i * 34} L 372 ${164 + i * 34}`} stroke={col} strokeWidth={4} strokeLinecap="round" opacity={progress} />)
            : [1, 4, 5, 9].map((i) => <ellipse key={i} cx={250} cy={150 + i * 34} rx={140} ry={17} fill="none" stroke={col} strokeWidth={4} opacity={progress} />)}
          {variant === 1
            ? [1, 4, 7].map((i) => <circle key={i} cx={52} cy={150 + i * 34} r={9} fill={col} opacity={progress} />)
            : [0, 3, 8].map((i) => <path key={i} d={`M 38 ${150 + i * 34 - 10} l 14 10 l -14 10`} fill="none" stroke={col} strokeWidth={4} opacity={progress} />)}
        </svg>
        <div style={{position: "absolute", top: 54, left: 0, right: 0, textAlign: "center", fontFamily: FONT.serif, fontWeight: 700, fontSize: 38, color: C.inkBrown}}>{label}</div>
      </Manuscript>
    </div>
  );
};

export const SceneB: React.FC = () => {
  const t = useT();

  // ---- B1: judul + urutan gerak (12,8 – 19,6)
  const b1Out = seg(t, 19.3, 19.95, easeInOut);
  const figIn = seg(t, 15.9, 16.6, easeOut);
  const rkIn = seg(t, 17.0, 17.5, easeOut);
  const capIn = seg(t, 17.96, 18.5, easeOut);
  const chipIn = seg(t, 14.6, 15.2, easeOut);

  // ---- B2..B5: manuskrip
  const cardIn = seg(t, 19.6, 20.5, easeOut);
  const shrink = seg(t, 36.9, 37.7, easeInOut);
  const cardScale = lerp(1, 0.56, shrink);
  const cardY = lerp(0, -150, shrink);
  const titleDim = 1 - 0.55 * seg(t, 25.3, 26.0);

  const refA = seg(t, 24.02, 24.5, easeOut);
  const refB = seg(t, 24.7, 25.2, easeOut);

  const sheetsIn = seg(t, 37.2, 38.2, easeOut);
  const sheetsFade = seg(t, 41.0, 41.5);
  const thread = seg(t, 39.52, 40.6, easeInOut);
  const tag = springAt(t, 40.0);

  return (
    <AbsoluteFill>
      {/* ---------------- B1 ---------------- */}
      <AbsoluteFill style={{opacity: 1 - b1Out, transform: `translateY(${-b1Out * 120}px) scale(${1 - b1Out * 0.08})`, filter: `blur(${b1Out * 12}px)`}}>
        <div style={{position: "absolute", left: 96, top: 190}}>
          <EditorialTitle kicker="Pendapat pertama" title="Mazhab Syafi'i" at={13.0} width={888} />
        </div>
        <div style={{position: "absolute", left: 0, right: 0, top: 560, display: "flex", justifyContent: "center", opacity: chipIn, transform: `translateY(${(1 - chipIn) * 24}px)`}}>
          <Chip text="Qunut Subuh · Hukumnya Sunnah" size={34} />
        </div>
        <div style={{position: "absolute", left: 0, right: 0, top: 665, display: "flex", justifyContent: "center", opacity: figIn, transform: `translateY(${(1 - figIn) * 50}px)`}}>
          <PrayerSequence mode="syafii" figureSize={560} markerAt={18.94} />
        </div>
        <div style={{position: "absolute", left: 96, top: 700, opacity: rkIn, transform: `translateX(${(1 - rkIn) * -40}px)`}}>
          <div style={{fontFamily: FONT.sans, fontWeight: 600, fontSize: 24, letterSpacing: 6, color: C.gold, textTransform: "uppercase"}}>Subuh</div>
          <div style={{fontFamily: FONT.serif, fontWeight: 700, fontSize: 84, lineHeight: 0.95, color: C.ivory}}>Rakaat<br />ke-2</div>
        </div>
        <div style={{position: "absolute", left: 0, right: 0, top: 1450, textAlign: "center", opacity: capIn, transform: `translateY(${(1 - capIn) * 20}px)`}}>
          <div style={{fontFamily: FONT.serif, fontStyle: "italic", fontWeight: 500, fontSize: 48, color: C.goldLight}}>dibaca setelah bangkit dari rukuk</div>
        </div>
      </AbsoluteFill>

      {/* ---------------- B2–B5 ---------------- */}
      <AbsoluteFill style={{alignItems: "center"}}>
        <div style={{position: "absolute", top: 330, transformOrigin: "50% 0%", transform: `translateY(${cardY + (1 - cardIn) * 160}px) scale(${cardScale}) rotate(${(1 - cardIn) * -3}deg)`, opacity: cardIn}}>
          <Manuscript width={920} height={1080} reveal={cardIn}>
            <div style={{position: "absolute", top: 80, left: 0, right: 0, textAlign: "center", opacity: titleDim}}>
              <div style={{fontFamily: FONT.sans, fontWeight: 600, fontSize: 24, letterSpacing: 9, color: C.goldDeep, textTransform: "uppercase", opacity: seg(t, 19.62, 20.2)}}>Dalil utama</div>
              <div style={{marginTop: 8}}>
                <KineticWords
                  size={84}
                  width={820}
                  color={C.inkBrown}
                  words={[
                    {text: "Hadis", at: 20.72, weight: 700},
                    {text: "Anas", at: 20.98, weight: 700},
                    {text: "bin", at: 21.34, weight: 700},
                    {text: "Malik", at: 21.5, weight: 700},
                  ]}
                />
              </div>
              <div style={{display: "flex", justifyContent: "center", gap: 18, marginTop: 26}}>
                <div style={{opacity: refA, transform: `translateY(${(1 - refA) * 16}px)`}}><Chip text="Imam Ahmad" color={C.goldDeep} bg="#f6efdc" size={26} /></div>
                <div style={{opacity: refB, transform: `translateY(${(1 - refB) * 16}px)`}}><Chip text="Ad-Daruquthni" color={C.goldDeep} bg="#f6efdc" size={26} /></div>
              </div>
            </div>
            <div style={{position: "absolute", top: 330, left: 0, right: 0, display: "flex", justifyContent: "center"}}>
              <ArabicLine
                words={HADITH_ANAS_QUNUT.words}
                times={HADITH_ANAS_QUNUT.times}
                size={80}
                width={800}
                color={C.inkBrown}
                activeColor={C.copper}
                glow={C.gold}
                lineHeight={1.6}
              />
            </div>
            <div style={{position: "absolute", top: 790, left: 0, right: 0, display: "flex", flexDirection: "column", alignItems: "center", opacity: seg(t, 32.05, 32.5)}}>
              <GoldDivider width={460} progress={seg(t, 32.1, 32.9, easeOut)} color={C.goldDeep} />
              <div style={{marginTop: 14, fontFamily: FONT.sans, fontWeight: 600, fontSize: 22, letterSpacing: 8, color: C.goldDeep, textTransform: "uppercase"}}>Artinya</div>
              <div style={{marginTop: 10}}>
                <TimedText words={TR_ANAS_QUNUT} size={56} width={780} color={C.inkBrown} activeColor={C.copper} italic />
              </div>
            </div>
          </Manuscript>
        </div>

        {/* B5 — dua lembar kajian: derajat hadis diperselisihkan */}
        <div style={{position: "absolute", top: 800, left: 0, right: 0, display: "flex", flexDirection: "column", alignItems: "center", opacity: sheetsIn * (1 - sheetsFade)}}>
          <div style={{display: "flex", gap: 36, transform: `translateY(${(1 - sheetsIn) * 80}px)`}}>
            <StudySheet variant={1} label="Penilaian ulama (1)" progress={sheetsIn} />
            <StudySheet variant={2} label="Penilaian ulama (2)" progress={sheetsIn} />
          </div>
          <div style={{marginTop: 26}}>
            <KineticWords
              size={64}
              width={900}
              words={[
                {text: "Derajat", at: 37.18, weight: 700},
                {text: "hadis", at: 37.5, weight: 700},
                {text: "diperselisihkan", at: 38.22, weight: 700, color: C.goldLight, italic: true},
                {text: "ulama", at: 38.84, weight: 700, color: C.goldLight, italic: true},
              ]}
            />
          </div>
        </div>
        {/* benang emas → penanda Syafi'iyah */}
        <svg width={1080} height={1920} style={{position: "absolute", inset: 0, opacity: 1 - sheetsFade}}>
          <path d={`M 540 ${1590 - 70 * thread} L 540 1590`} stroke={C.gold} strokeWidth={4} fill="none" strokeLinecap="round" opacity={thread}/>
        </svg>
        {t > 39.5 && (
          <div style={{position: "absolute", top: 1590, left: 0, right: 0, display: "flex", justifyContent: "center", opacity: (1 - sheetsFade) * Math.min(1, tag * 1.5), transform: `scale(${0.7 + 0.3 * tag})`}}>
            <div style={{display: "flex", alignItems: "center", gap: 18, padding: "20px 44px", borderRadius: 999, background: "#06302af0", border: `3px solid ${C.gold}`, boxShadow: `0 0 50px ${C.gold}77`}}>
              <Star8 size={40} />
              <div style={{fontFamily: FONT.serif, fontWeight: 700, fontSize: 46, color: C.ivory}}>Dipegang oleh Syafi'iyah</div>
            </div>
          </div>
        )}
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
