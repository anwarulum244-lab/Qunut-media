import React from "react";
import {AbsoluteFill} from "remotion";
import {C, FONT} from "../theme";
import {easeInOut, easeOut, seg, springAt, useT} from "../helpers/anim";
import {KineticWords} from "../components/Text";
import {Glass} from "../components/Panels";

const Factor: React.FC<{n: string; title: string; sub: string; p: number}> = ({n, title, sub, p}) => (
  <div style={{opacity: p, transform: `translateY(${(1 - p) * 60}px) scale(${0.92 + 0.08 * p})`}}>
    <Glass width={430} height={340} glow={p * 0.6}>
      <div style={{position: "absolute", inset: 0, padding: "30px 34px"}}>
        <div style={{fontFamily: FONT.serif, fontWeight: 700, fontSize: 80, lineHeight: 0.9, color: C.gold}}>{n}</div>
        <div style={{fontFamily: FONT.serif, fontWeight: 700, fontSize: 44, lineHeight: 1.05, color: C.ivory, marginTop: 6}}>{title}</div>
        <div style={{fontFamily: FONT.sans, fontWeight: 400, fontSize: 23, lineHeight: 1.3, color: C.parchmentDark, marginTop: 10}}>{sub}</div>
      </div>
    </Glass>
  </div>
);

const MazhabCard: React.FC<{name: string; line: string; p: number; ghost: number}> = ({name, line, p, ghost}) => (
  <div style={{position: "relative", width: 430, height: 230}}>
    <div style={{position: "absolute", inset: 0, borderRadius: 26, border: `2px dashed ${C.gold}`, opacity: ghost * (1 - p) * 0.5}} />
    <div style={{opacity: p, transform: `scale(${0.9 + 0.1 * p})`}}>
      <Glass width={430} height={230} glow={p * 0.4}>
        <div style={{position: "absolute", inset: 0, padding: "26px 32px"}}>
          <div style={{fontFamily: FONT.serif, fontWeight: 700, fontSize: 56, color: C.goldLight, lineHeight: 1}}>{name}</div>
          <div style={{fontFamily: FONT.sans, fontWeight: 400, fontSize: 25, lineHeight: 1.35, color: C.ivory, marginTop: 14}}>{line}</div>
        </div>
      </Glass>
    </div>
  </div>
);

export const SceneF: React.FC = () => {
  const t = useT();
  const kick = seg(t, 125.2, 125.8, easeOut);
  const f1 = seg(t, 127.8, 128.5, easeOut);
  const f2 = seg(t, 129.88, 130.5, easeOut);
  const lines = seg(t, 130.7, 131.5, easeInOut);
  const hub = springAt(t, 131.0);
  const ghost = seg(t, 128.8, 129.4);
  const cards = [seg(t, 131.35, 131.8, easeOut), seg(t, 131.6, 132.05, easeOut), seg(t, 131.8, 132.25, easeOut), seg(t, 132.0, 132.45, easeOut)];

  return (
    <AbsoluteFill>
      <div style={{position: "absolute", left: 96, top: 190, width: 888, textAlign: "center"}}>
        <div style={{fontFamily: FONT.sans, fontWeight: 600, fontSize: 28, letterSpacing: 10 * kick, color: C.gold, opacity: kick, textTransform: "uppercase", marginBottom: 12}}>Inti perbedaan</div>
        <KineticWords
          size={104}
          width={888}
          words={[
            {text: "Perbedaannya", at: 125.8, weight: 700, breakAfter: true},
            {text: "pada", at: 126.78, weight: 700, color: C.goldLight},
            {text: "dua", at: 127.0, weight: 700, color: C.goldLight, italic: true},
            {text: "hal", at: 127.2, weight: 700, color: C.goldLight, italic: true},
          ]}
        />
      </div>

      <div style={{position: "absolute", left: 96, top: 600, display: "flex", gap: 28}}>
        <Factor n="I" title="Derajat hadis Anas" sub="Hadis: Nabi terus berqunut Subuh sampai wafat" p={f1} />
        <Factor n="II" title="Makna riwayat Nabi meninggalkan qunut" sub="Apa sebenarnya yang ditinggalkan Nabi?" p={f2} />
      </div>

      {/* garis argumentasi → simpul → empat mazhab */}
      <svg width={1080} height={1920} style={{position: "absolute", inset: 0}}>
        <defs><filter id="fg"><feGaussianBlur stdDeviation="4" /></filter></defs>
        {[{x: 311, c: C.gold}, {x: 769, c: C.copperLight}].map((s, i) => (
          <g key={i}>
            <path d={`M ${s.x} 930 C ${s.x} 1000, 540 980, 540 1040`} stroke={s.c} strokeWidth={4} fill="none" strokeDasharray="260" strokeDashoffset={260 * (1 - lines)} filter="url(#fg)" opacity={0.8} />
            <path d={`M ${s.x} 930 C ${s.x} 1000, 540 980, 540 1040`} stroke={C.ivory} strokeWidth={2} fill="none" strokeDasharray="260" strokeDashoffset={260 * (1 - lines)} />
          </g>
        ))}
        {[{x: 311, y: 1150}, {x: 769, y: 1150}].map((s, i) => (
          <path key={i} d={`M 540 1100 C 540 1130, ${s.x} 1120, ${s.x} 1160`} stroke={C.goldLight} strokeWidth={2.5} fill="none" strokeDasharray="120" strokeDashoffset={120 * (1 - cards[0])} opacity={0.8} />
        ))}
      </svg>
      <div style={{position: "absolute", left: 240, top: 1032, width: 600, display: "flex", justifyContent: "center", opacity: Math.min(1, hub * 1.4), transform: `scale(${0.7 + 0.3 * hub})`}}>
        <div style={{padding: "12px 34px", borderRadius: 999, border: `2.5px solid ${C.goldLight}`, background: "#06302af0", fontFamily: FONT.serif, fontWeight: 700, fontSize: 38, whiteSpace: "nowrap", color: C.ivory, boxShadow: `0 0 40px ${C.gold}66`}}>
          Penilaian &amp; penafsiran
        </div>
      </div>

      <div style={{position: "absolute", left: 96, top: 1160, display: "grid", gridTemplateColumns: "430px 430px", gap: 28}}>
        <MazhabCard name="Syafi'i" line="Sunnah · dibaca setelah rukuk" p={cards[0]} ghost={ghost} />
        <MazhabCard name="Hanafi" line="Tidak disunnahkan · qunut pada witir & musibah" p={cards[1]} ghost={ghost} />
        <MazhabCard name="Hanbali" line="Tidak disunnahkan · qunut pada witir & musibah" p={cards[2]} ghost={ghost} />
        <MazhabCard name="Maliki" line="Mustahab · sebelum rukuk · suara pelan" p={cards[3]} ghost={ghost} />
      </div>
    </AbsoluteFill>
  );
};
