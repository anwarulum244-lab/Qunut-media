import React from "react";
import {AbsoluteFill} from "remotion";
import {C, FONT} from "../theme";
import {easeInOut, easeOut, lerp, seg, springAt, useT} from "../helpers/anim";
import {Chip, GoldDivider} from "../components/Ornaments";

type Book = {latin: string; arabic: string; start: number; end: number; mazhab: string; mazhabAt: number; cover: string; band: string};

/** Hanya kitab & mazhab yang disebut dalam narasi. */
export const BOOKS: Book[] = [
  {latin: "Al-Umm", arabic: "الأم", start: 134.3, end: 135.2, mazhab: "Syafi'i", mazhabAt: 136.52, cover: "#14503f", band: C.gold},
  {latin: "Al-Majmu'", arabic: "المجموع", start: 135.22, end: 137.3, mazhab: "Syafi'i", mazhabAt: 136.52, cover: "#0f4636", band: C.gold},
  {latin: "Al-Hidayah", arabic: "الهداية", start: 137.32, end: 139.44, mazhab: "Hanafi", mazhabAt: 138.58, cover: "#5a3320", band: C.copperLight},
  {latin: "Al-Mughni", arabic: "المغني", start: 139.46, end: 141.7, mazhab: "Hanbali", mazhabAt: 140.9, cover: "#1c3d4f", band: C.goldLight},
];

const activeIndex = (t: number) => {
  let idx = -1;
  BOOKS.forEach((b, i) => {
    if (t >= b.start) idx = i;
  });
  return idx;
};

const Spine: React.FC<{b: Book; i: number; active: boolean; lift: number; ribbon: number; appear: number}> = ({b, active, lift, ribbon, appear}) => (
  <div style={{position: "relative", width: 210, height: 360, transform: `translateY(${(1 - appear) * 80 - lift * 46}px)`, opacity: appear * (active ? 1 : 0.6)}}>
    <div style={{position: "absolute", inset: 0, borderRadius: "10px 10px 4px 4px", background: `linear-gradient(90deg, #00000066 0%, ${b.cover} 12%, ${b.cover} 82%, #00000088 100%)`, border: `2px solid ${b.band}`, boxShadow: active ? `0 0 60px ${b.band}99, 0 30px 50px #000c` : "0 24px 40px #000b"}}>
      {[24, 52, 300, 328].map((y) => (
        <div key={y} style={{position: "absolute", left: 0, right: 0, top: y, height: 6, background: b.band, opacity: 0.85}} />
      ))}
      <div style={{position: "absolute", left: 0, right: 0, top: 70, bottom: 70, display: "flex", alignItems: "center", justifyContent: "center"}}>
        <div style={{writingMode: "vertical-rl", whiteSpace: "nowrap", fontFamily: FONT.serif, fontWeight: 700, fontSize: 44, color: C.goldLight, letterSpacing: 3, textShadow: "0 2px 8px #000"}}>{b.latin}</div>
      </div>
    </div>
    {/* pita mazhab */}
    <div style={{position: "absolute", left: 14, right: 14, bottom: -58, textAlign: "center", opacity: ribbon, transform: `translateY(${(1 - ribbon) * -14}px)`}}>
      <div style={{display: "inline-block", fontFamily: FONT.sans, fontWeight: 600, fontSize: 22, letterSpacing: 4, textTransform: "uppercase", color: C.ink, background: b.band, padding: "6px 16px", borderRadius: 999}}>{b.mazhab}</div>
    </div>
  </div>
);

const OpenBook: React.FC<{t: number; active: number}> = ({t, active}) => {
  const b = BOOKS[Math.max(0, active)];
  const open = seg(t, 132.7, 133.9, easeInOut);
  const local = Math.max(0, t - b.start);
  const lineIdx = Math.min(8, Math.floor(local * 2.2));
  const mark = seg(t, b.start, b.start + 0.5, easeOut);
  const drawW = seg(t, b.start, b.start + 0.7, easeOut);
  const page = (side: "l" | "r") => (
    <div style={{width: 400, height: 500, position: "relative", background: `linear-gradient(${side === "l" ? 90 : 270}deg, ${C.parchmentDark}, ${C.parchment} 22%, #fbf1d4 100%)`, borderRadius: side === "l" ? "10px 0 0 10px" : "0 10px 10px 0", transform: `rotateY(${(side === "l" ? 1 : -1) * (1 - open) * 78}deg)`, transformOrigin: side === "l" ? "right center" : "left center", boxShadow: "inset 0 0 50px #8f6a2255"}}>
      <div style={{position: "absolute", top: 36, left: 40, right: 40, textAlign: "center", fontFamily: FONT.arabic, fontSize: 46, color: C.inkBrown}} dir="rtl">{side === "l" ? b.arabic : ""}</div>
      {Array.from({length: 11}).map((_, i) => {
        const y = 110 + i * 34;
        const w = 270 + ((i * 47 + (side === "l" ? 13 : 61)) % 70);
        const isTarget = side === "r" && i === lineIdx + 1;
        return (
          <React.Fragment key={i}>
            <div style={{position: "absolute", top: y, right: 40, width: w, height: 6, borderRadius: 3, background: C.inkBrown, opacity: 0.4}} />
            {isTarget && (
              <div style={{position: "absolute", top: y - 9, right: 34, width: (w + 12) * drawW, height: 24, borderRadius: 6, background: C.gold, opacity: 0.45 * mark, mixBlendMode: "multiply"}} />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
  return (
    <div style={{display: "flex", perspective: 1800, filter: `drop-shadow(0 40px 50px #000c)`}}>
      {page("l")}
      <div style={{width: 6, background: `linear-gradient(180deg, ${C.goldDeep}, ${C.gold}, ${C.goldDeep})`}} />
      {page("r")}
    </div>
  );
};

export const SceneG: React.FC = () => {
  const t = useT();
  const a = activeIndex(t);
  const head = seg(t, 132.7, 133.4, easeOut);
  // kamera menelusuri: geser & mendekat perlahan
  const drift = seg(t, 132.6, 141.6, (x) => x);
  const camScale = lerp(1.0, 1.1, drift);
  const camX = Math.sin(drift * Math.PI * 1.2) * 22;
  const shelf = seg(t, 133.0, 134.0, easeOut);
  const book = a >= 0 ? BOOKS[a] : null;
  const label = book ? seg(t, book.start, book.start + 0.45, easeOut) : 0;
  const ul = book ? seg(t, book.start + 0.1, book.start + 0.9, easeOut) : 0;

  return (
    <AbsoluteFill>
      <div style={{position: "absolute", left: 96, top: 180, width: 888, textAlign: "center", opacity: head, transform: `translateY(${(1 - head) * 30}px)`}}>
        <div style={{fontFamily: FONT.sans, fontWeight: 600, fontSize: 28, letterSpacing: 10, color: C.gold, textTransform: "uppercase"}}>Rujukan kitab</div>
        <div style={{fontFamily: FONT.serif, fontWeight: 700, fontSize: 84, color: C.ivory, lineHeight: 1.05, marginTop: 8}}>Telusuri literatur fikih</div>
        <div style={{display: "flex", justifyContent: "center", marginTop: 10}}><GoldDivider width={560} progress={head} /></div>
      </div>

      <AbsoluteFill style={{transform: `translateX(${camX}px) scale(${camScale})`, transformOrigin: "50% 45%"}}>
        <div style={{position: "absolute", left: 0, right: 0, top: 440, display: "flex", justifyContent: "center", transform: "rotateX(14deg)", opacity: head}}>
          <OpenBook t={t} active={a} />
        </div>
        <div style={{position: "absolute", left: 96, top: 1000, display: "flex", gap: 14}}>
          {BOOKS.map((b, i) => (
            <Spine
              key={b.latin}
              b={b}
              i={i}
              active={a === i}
              lift={a === i ? springAt(t, b.start, {damping: 12, stiffness: 140, mass: 0.7}) : 0}
              ribbon={seg(t, b.mazhabAt, b.mazhabAt + 0.5, easeOut)}
              appear={Math.min(1, shelf * (1 + 0.0 * i))}
            />
          ))}
        </div>
      </AbsoluteFill>

      {/* label hierarki tipografi untuk kitab yang sedang disebut */}
      {book && (
        <div style={{position: "absolute", left: 96, width: 888, top: 1448, textAlign: "center", opacity: label}}>
          <div style={{fontFamily: FONT.serif, fontWeight: 700, fontSize: 124, lineHeight: 1, color: C.ivory, transform: `translateY(${(1 - label) * 30}px)`, textShadow: `0 0 50px ${book.band}88`}}>{book.latin}</div>
          <div style={{fontFamily: FONT.arabic, fontSize: 64, color: C.goldLight, marginTop: 2}} dir="rtl">{book.arabic}</div>
          <div style={{margin: "8px auto 0", height: 5, width: 520 * ul, background: book.band, borderRadius: 3, boxShadow: `0 0 20px ${book.band}`}} />
          <div style={{marginTop: 16, height: 48, opacity: seg(t, book.mazhabAt, book.mazhabAt + 0.5)}}>
            <Chip text={`Mazhab ${book.mazhab}`} color={book.band} size={26} />
          </div>
        </div>
      )}
    </AbsoluteFill>
  );
};
