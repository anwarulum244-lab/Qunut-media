import React from "react";
import {AbsoluteFill} from "remotion";
import {C, FONT, H, W} from "../theme";
import {easeInOut, easeOut, lerp, seg, springAt, useT} from "../helpers/anim";
import {Mosque} from "../components/Mosque";
import {KineticWords} from "../components/Text";
import {PrayerFigure, POSES} from "../components/PrayerFigure";
import {Star8, STAR8} from "../components/Ornaments";

const MEDALLIONS = [
  {name: "Syafi'i", color: C.gold, kind: "figure" as const},
  {name: "Hanafi", color: C.teal, kind: "book" as const},
  {name: "Hanbali", color: C.goldLight, kind: "scroll" as const},
  {name: "Maliki", color: C.copperLight, kind: "figure2" as const},
];

const Medallion: React.FC<{kind: "figure" | "book" | "scroll" | "figure2"; color: string}> = ({kind, color}) => (
  <div style={{width: 190, height: 190, borderRadius: "50%", border: `3px solid ${color}`, background: "#04100fdd", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 40px ${color}66`, overflow: "hidden"}}>
    {kind === "figure" && <PrayerFigure pose={POSES.itidal} raise={1} size={176} color={C.goldLight} />}
    {kind === "figure2" && <PrayerFigure pose={POSES.qiyam} raise={1} size={176} color={C.goldLight} />}
    {kind === "book" && (
      <svg width={120} height={120} viewBox="0 0 120 120">
        <path d="M10 28 L58 36 L58 100 L10 92 Z" fill="#5a3320" stroke={color} strokeWidth={3} />
        <path d="M110 28 L62 36 L62 100 L110 92 Z" fill="#efe3c2" stroke={color} strokeWidth={3} />
      </svg>
    )}
    {kind === "scroll" && (
      <svg width={120} height={120} viewBox="0 0 120 120">
        <rect x="28" y="20" width="64" height="80" rx="8" fill="#efe3c2" stroke={color} strokeWidth={3} />
        {[40, 54, 68, 82].map((y) => <line key={y} x1="40" x2="80" y1={y} y2={y} stroke="#2a1b0e" strokeWidth="4" strokeLinecap="round" opacity="0.5" />)}
      </svg>
    )}
  </div>
);

export const SceneH: React.FC<{endSec: number}> = ({endSec}) => {
  const t = useT();
  const local = seg(t, 141.6, endSec, (x) => x);
  // kamera perlahan menjauh
  const scale = lerp(1.25, 1.0, easeInOut(local));
  const camY = lerp(-60, 0, easeInOut(local));
  const appear = seg(t, 141.6, 143.0, easeOut);
  const conv = seg(t, 141.8, 143.3, easeInOut);
  const respect = seg(t, 144.0, 144.8);
  const hikmahIn = seg(t, 145.3, 145.8, easeOut);
  const textA = 1 - seg(t, 145.1, 145.5);
  const textB = hikmahIn * (1 - seg(t, 148.5, 148.9));
  const textC = seg(t, 149.3, 149.7) ;
  const barIn = seg(t, 147.2, 147.9, easeOut);
  const barPulse = springAt(t, 147.96, {damping: 8, stiffness: 160, mass: 0.6});
  const caret = Math.floor(t * 2) % 2 === 0 ? 1 : 0;
  const phase1 = "Tulis komentar…";
  const phase2 = "Topik fikih berikutnya…";
  const type2 = Math.max(0, Math.min(phase2.length, Math.floor((t - 149.5) * 7.5)));
  const shown = t < 149.4 ? phase1 : phase2.slice(0, type2);

  return (
    <AbsoluteFill>
      {/* matahari terbit hangat di belakang masjid */}
      <AbsoluteFill style={{transform: `translateY(${camY}px) scale(${scale})`, transformOrigin: "50% 60%", opacity: appear}}>
        <div style={{position: "absolute", left: W / 2 - 600, top: 760, width: 1200, height: 1200, borderRadius: "50%", background: `radial-gradient(circle, ${C.gold}66 0%, ${C.copper}22 40%, transparent 70%)`}} />
        <div style={{position: "absolute", left: -120, top: 690, opacity: 0.6}}><Mosque variant={3} glow={C.gold} width={520} id="hA" /></div>
        <div style={{position: "absolute", left: 640, top: 700, opacity: 0.6}}><Mosque variant={2} glow={C.goldLight} width={520} id="hB" /></div>
        <div style={{position: "absolute", left: 270, top: 640}}><Mosque variant={1} glow={C.gold} width={540} id="hC" /></div>
        <div style={{position: "absolute", left: 0, top: 1150, width: W, height: 40, background: "linear-gradient(180deg,#010504,transparent)"}} />
      </AbsoluteFill>

      {/* Teks */}
      <div style={{position: "absolute", left: 96, top: 190, width: 888, opacity: textA}}>
        <KineticWords
          size={86}
          width={888}
          words={[
            {text: "Perbedaan", at: 141.78, weight: 700},
            {text: "seperti", at: 142.22, weight: 700},
            {text: "ini", at: 142.4, weight: 700, breakAfter: true},
            {text: "mengajarkan", at: 142.8, weight: 700, color: C.goldLight},
            {text: "kita", at: 143.28, weight: 700, color: C.goldLight},
            {text: "untuk", at: 143.72, weight: 700, color: C.goldLight, breakAfter: true},
            {text: "saling", at: 143.98, weight: 700, italic: true, color: C.ivory},
            {text: "menghormati.", at: 144.44, weight: 700, italic: true, color: C.gold},
          ]}
        />
      </div>
      <div style={{position: "absolute", left: 96, top: 230, width: 888, opacity: textB}}>
        <KineticWords
          size={104}
          width={888}
          words={[
            {text: "Menurut", at: 145.44, weight: 700},
            {text: "kamu,", at: 145.76, weight: 700, breakAfter: true},
            {text: "apa", at: 146.34, weight: 700, color: C.goldLight},
            {text: "hikmahnya?", at: 146.54, weight: 700, italic: true, color: C.gold},
          ]}
        />
      </div>
      <div style={{position: "absolute", left: 96, top: 230, width: 888, opacity: textC}}>
        <KineticWords
          size={92}
          width={888}
          words={[
            {text: "Topik", at: 149.5, weight: 700},
            {text: "fikih", at: 149.76, weight: 700, color: C.goldLight},
            {text: "berikutnya?", at: 150.92, weight: 700, italic: true, color: C.gold, breakAfter: true},
            {text: "Sebutkan", at: 151.76, weight: 600, size: 62, color: C.ivory},
            {text: "juga", at: 152.08, weight: 600, size: 62, color: C.ivory},
            {text: "ya.", at: 152.3, weight: 600, size: 62, color: C.ivory},
          ]}
        />
      </div>

      {/* Empat mazhab menyatu mengelilingi bintang */}
      <AbsoluteFill style={{pointerEvents: "none"}}>
        <div style={{position: "absolute", left: W / 2 - 60, top: 1010 - 60, opacity: conv, transform: `rotate(${t * 10}deg) scale(${1 + respect * 0.2})`, filter: `drop-shadow(0 0 ${30 * respect}px ${C.gold})`}}>
          <Star8 size={120} color={C.goldLight} fill={`${C.gold}33`} stroke={3} />
        </div>
        {MEDALLIONS.map((m, i) => {
          const ang = (-Math.PI / 2) + (i * Math.PI * 2) / 4 + Math.PI / 4 + t * 0.05;
          const R = lerp(620, 270, conv);
          const x = W / 2 + Math.cos(ang) * R * 1.12 - 95;
          const y = 1010 + Math.sin(ang) * R * 0.7 - 95;
          return (
            <div key={m.name} style={{position: "absolute", left: x, top: y, opacity: conv, transform: `scale(${0.6 + 0.4 * conv + respect * 0.05})`, textAlign: "center"}}>
              <Medallion kind={m.kind} color={m.color} />
              <div style={{fontFamily: FONT.serif, fontWeight: 700, fontSize: 34, color: C.ivory, marginTop: 8}}>{m.name}</div>
            </div>
          );
        })}
      </AbsoluteFill>

      {/* Antarmuka komentar minimalis */}
      <div style={{position: "absolute", left: 120, width: 840, top: 1490, opacity: barIn, transform: `translateY(${(1 - barIn) * 50}px) scale(${1 + 0.03 * Math.max(0, barPulse - 0.8)})`}}>
        <div style={{height: 112, borderRadius: 56, background: "#f6efdcee", border: `3px solid ${C.gold}`, boxShadow: `0 20px 60px #000b, 0 0 ${40 * Math.min(1, barPulse)}px ${C.gold}88`, display: "flex", alignItems: "center", padding: "0 30px", gap: 22}}>
          <div style={{width: 62, height: 62, borderRadius: "50%", background: `linear-gradient(135deg, ${C.emerald}, ${C.emeraldLight})`, border: `2px solid ${C.goldDeep}`}} />
          <div style={{flex: 1, fontFamily: FONT.sans, fontWeight: 400, fontSize: 36, color: "#2a1b0e99"}}>
            {shown}
            <span style={{opacity: caret, color: C.copper}}>|</span>
          </div>
          <svg width={52} height={52} viewBox="0 0 52 52"><path d="M6 8 H46 V34 H24 L12 46 V34 H6 Z" fill="none" stroke={C.goldDeep} strokeWidth={3.5} strokeLinejoin="round" /></svg>
        </div>
      </div>
    </AbsoluteFill>
  );
};
