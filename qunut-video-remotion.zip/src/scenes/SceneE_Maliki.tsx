import React from "react";
import {AbsoluteFill} from "remotion";
import {C, FONT} from "../theme";
import {easeOut, seg, springAt, useT} from "../helpers/anim";
import {EditorialTitle} from "../components/Text";
import {Chip} from "../components/Ornaments";
import {PrayerSequence, stageOfQunut, QunutMode} from "../components/PrayerSequence";

const STAGES = ["Berdiri", "Rukuk", "I'tidal", "Sujud"];

/** Strip perbandingan posisi qunut — dihasilkan dari fungsi yang sama dengan animasi utama. */
const MiniStrip: React.FC<{mode: QunutMode; label: string; active: boolean}> = ({mode, label, active}) => {
  const q = stageOfQunut(mode);
  return (
    <div style={{display: "flex", alignItems: "center", gap: 22, opacity: active ? 1 : 0.55}}>
      <div style={{width: 190, fontFamily: FONT.serif, fontWeight: 700, fontSize: 42, color: active ? C.goldLight : C.ivory}}>{label}</div>
      <div style={{display: "flex", gap: 10, flex: 1}}>
        {STAGES.map((s, i) => (
          <div key={s} style={{flex: 1, textAlign: "center"}}>
            <div style={{height: 14, borderRadius: 7, background: i === q ? C.gold : "#ffffff30", boxShadow: i === q ? `0 0 22px ${C.gold}` : "none"}} />
            <div style={{fontFamily: FONT.sans, fontWeight: 600, fontSize: 18, color: i === q ? C.goldLight : C.parchmentDark, marginTop: 8, letterSpacing: 1}}>{s}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export const SceneE: React.FC = () => {
  const t = useT();
  const chipIn = seg(t, 121.42, 122.0, easeOut);
  const figIn = seg(t, 120.2, 120.9, easeOut);
  const before = seg(t, 123.36, 123.9, easeOut);
  const quiet = springAt(t, 124.42);
  const strip = seg(t, 124.3, 124.8, easeOut);
  // gelombang suara pelan (amplitudo kecil)
  const bars = Array.from({length: 9}).map((_, i) => 6 + 8 * Math.abs(Math.sin(t * 5 + i * 0.9)) * quiet);

  return (
    <AbsoluteFill>
      <div style={{position: "absolute", left: 96, top: 180}}>
        <EditorialTitle kicker="Pendapat ketiga" title="Mazhab Maliki" at={119.66} width={888} accent={C.copperLight} />
      </div>
      <div style={{position: "absolute", left: 0, right: 0, top: 520, display: "flex", justifyContent: "center", opacity: chipIn, transform: `translateY(${(1 - chipIn) * 24}px)`}}>
        <Chip text="Qunut Subuh · Mustahab" size={34} color={C.copperLight} />
      </div>
      <div style={{position: "absolute", left: 0, right: 0, top: 610, display: "flex", justifyContent: "center", opacity: figIn, transform: `translateY(${(1 - figIn) * 50}px)`}}>
        <PrayerSequence mode="maliki" figureSize={500} markerAt={121.8} />
      </div>
      <div style={{position: "absolute", left: 0, right: 0, top: 1290, textAlign: "center", opacity: before, transform: `translateY(${(1 - before) * 20}px)`}}>
        <div style={{fontFamily: FONT.serif, fontStyle: "italic", fontWeight: 500, fontSize: 52, color: C.goldLight}}>dibaca <span style={{fontWeight: 700, color: C.ivory}}>sebelum</span> rukuk</div>
      </div>
      <div style={{position: "absolute", left: 0, right: 0, top: 1375, display: "flex", justifyContent: "center", alignItems: "center", gap: 22, opacity: Math.min(1, quiet * 1.5), transform: `scale(${0.85 + 0.15 * quiet})`}}>
        <svg width={120} height={50}>
          {bars.map((h, i) => (
            <rect key={i} x={i * 13} y={25 - h / 2} width={7} height={h} rx={3.5} fill={C.copperLight} />
          ))}
        </svg>
        <div style={{fontFamily: FONT.serif, fontWeight: 600, fontSize: 48, color: C.ivory}}>dengan suara pelan</div>
      </div>
      <div style={{position: "absolute", left: 96, width: 888, top: 1480, opacity: strip, transform: `translateY(${(1 - strip) * 30}px)`}}>
        <div style={{display: "flex", flexDirection: "column", gap: 18}}>
          <MiniStrip mode="syafii" label="Syafi'i" active={false} />
          <MiniStrip mode="maliki" label="Maliki" active />
        </div>
      </div>
    </AbsoluteFill>
  );
};
