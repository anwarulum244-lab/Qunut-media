import React from "react";
import {AbsoluteFill} from "remotion";
import {C, FONT, W} from "../theme";
import {easeInOut, easeOut, lerp, seg, springAt, useT} from "../helpers/anim";
import {ArabicLine, EditorialTitle, KineticWords, TimedText} from "../components/Text";
import {Chip, GoldDivider} from "../components/Ornaments";
import {Glass, Manuscript} from "../components/Panels";
import {HADITH_SAAD, TR_SAAD} from "../data/timeline";

/** Panel mazhab setara (struktur identik untuk Hanafi & Hanbali). */
const MazhabPanel: React.FC<{name: string; nameAt: number; ruleAt: number; witirAt: number; musibahAt: number}> = ({name, nameAt, ruleAt, witirAt, musibahAt}) => {
  const t = useT();
  const pIn = seg(t, nameAt, nameAt + 0.7, easeOut);
  const rule = seg(t, ruleAt, ruleAt + 0.5, easeOut);
  const w = springAt(t, witirAt);
  const m = springAt(t, musibahAt);
  return (
    <div style={{opacity: pIn, transform: `translateY(${(1 - pIn) * 60}px)`}}>
      <Glass width={888} height={410} glow={0.3}>
        <div style={{position: "absolute", inset: 0, padding: "40px 56px"}}>
          <div style={{fontFamily: FONT.sans, fontWeight: 600, fontSize: 26, letterSpacing: 9, color: C.gold, textTransform: "uppercase"}}>Mazhab</div>
          <div style={{fontFamily: FONT.serif, fontWeight: 700, fontSize: 92, color: C.ivory, lineHeight: 1}}>{name}</div>
          <div style={{marginTop: 22, display: "flex", alignItems: "center", gap: 18, opacity: rule, transform: `translateX(${(1 - rule) * -30}px)`}}>
            <div style={{width: 26, height: 26, borderRadius: "50%", border: `3px solid ${C.goldLight}`}} />
            <div style={{fontFamily: FONT.serif, fontWeight: 600, fontSize: 48, color: C.goldLight}}>Qunut Subuh: tidak disunnahkan</div>
          </div>
          <div style={{marginTop: 28, display: "flex", alignItems: "center", gap: 18}}>
            <div style={{fontFamily: FONT.sans, fontWeight: 600, fontSize: 22, letterSpacing: 5, color: C.parchmentDark, textTransform: "uppercase", opacity: seg(t, witirAt - 0.4, witirAt)}}>Qunut hanya:</div>
            <div style={{opacity: Math.min(1, w * 1.4), transform: `scale(${0.7 + 0.3 * w})`}}><Chip text="Shalat Witir" size={30} /></div>
            <div style={{opacity: Math.min(1, m * 1.4), transform: `scale(${0.7 + 0.3 * m})`}}><Chip text="Saat musibah" size={30} /></div>
          </div>
        </div>
      </Glass>
    </div>
  );
};

export const SceneD: React.FC = () => {
  const t = useT();
  const slide = seg(t, 77.15, 78.0, easeInOut);
  const d1x = -slide * W * 1.1;
  const d2x = (1 - slide) * W * 1.1;

  // Manuskrip Sa'ad: konten bergantian
  const cardIn = seg(t, 77.4, 78.2, easeOut);
  const cardOut = seg(t, 112.1, 112.6, easeInOut);
  const c2 = seg(t, 78.6, 79.0) * (1 - seg(t, 85.75, 86.15));
  const c3 = seg(t, 85.95, 86.3) * (1 - seg(t, 99.65, 100.05));
  const c4 = seg(t, 100.1, 100.5);
  const askIn = seg(t, 84.16, 84.8, easeOut);
  const lbl1 = seg(t, 86.1, 86.6, easeOut);
  const lbl2 = seg(t, 97.2, 97.7, easeOut);
  const trLbl1 = seg(t, 100.6, 101.0);
  const trLbl2 = seg(t, 108.9, 109.2);

  // D5
  const d5 = seg(t, 112.5, 113.2, easeOut);
  const bar = seg(t, 117.04, 118.06, easeInOut);
  const flag = springAt(t, 118.06);
  const mo = springAt(t, 117.48);
  const bk = seg(t, 114.6, 115.0, easeOut);
  const ms = seg(t, 115.2, 115.6, easeOut);

  return (
    <AbsoluteFill>
      {/* ---- D1 ---- */}
      <AbsoluteFill style={{transform: `translateX(${d1x}px)`, opacity: 1 - seg(t, 77.6, 78.0)}}>
        <div style={{position: "absolute", left: 96, top: 190}}>
          <EditorialTitle kicker="Pendapat kedua" title="Hanafi & Hanbali" at={69.66} width={888} size={106} />
        </div>
        <div style={{position: "absolute", left: 96, top: 520, display: "flex", flexDirection: "column", gap: 34}}>
          <MazhabPanel name="Hanafi" nameAt={70.2} ruleAt={71.92} witirAt={75.44} musibahAt={76.5} />
          <MazhabPanel name="Hanbali" nameAt={71.0} ruleAt={72.2} witirAt={75.5} musibahAt={76.6} />
        </div>
        {/* garis kecepatan kamera menyamping */}
        <div style={{position: "absolute", inset: 0, opacity: seg(t, 76.9, 77.3) * (1 - seg(t, 77.6, 78.0))}}>
          {[300, 560, 820, 1100, 1380, 1640].map((y, i) => (
            <div key={i} style={{position: "absolute", left: 0, top: y, width: 1080, height: 3, background: `linear-gradient(90deg, transparent, ${C.goldLight}, transparent)`, transform: `translateX(${slide * -400 * (1 + i * 0.2)}px)`}} />
          ))}
        </div>
      </AbsoluteFill>

      {/* ---- D2–D4: manuskrip Sa'ad bin Thariq ---- */}
      <AbsoluteFill style={{alignItems: "center", transform: `translateX(${d2x}px)`, opacity: cardIn * (1 - cardOut)}}>
        <div style={{position: "absolute", top: 290}}>
          <Manuscript width={940} height={1240} reveal={cardIn}>
            {/* D2 */}
            <div style={{position: "absolute", top: 120, left: 0, right: 0, textAlign: "center", opacity: c2}}>
              <div style={{fontFamily: FONT.sans, fontWeight: 600, fontSize: 24, letterSpacing: 9, color: C.goldDeep, textTransform: "uppercase"}}>Dalil mereka</div>
              <div style={{marginTop: 8}}>
                <KineticWords
                  size={78}
                  width={820}
                  color={C.inkBrown}
                  words={[
                    {text: "Hadis", at: 78.72, weight: 700},
                    {text: "Sa'ad", at: 79.14, weight: 700},
                    {text: "bin", at: 79.42, weight: 700},
                    {text: "Thariq", at: 79.7, weight: 700},
                    {text: "al-Asyja'i", at: 80.22, weight: 700, color: C.copper},
                  ]}
                />
              </div>
              <div style={{display: "flex", justifyContent: "center", marginTop: 30}}><GoldDivider width={520} progress={seg(t, 80.4, 81.2, easeOut)} color={C.goldDeep} /></div>
              <div style={{fontFamily: FONT.sans, fontWeight: 600, fontSize: 22, letterSpacing: 7, color: C.goldDeep, textTransform: "uppercase", marginTop: 14, opacity: seg(t, 81.0, 81.5)}}>Diriwayatkan oleh</div>
              <div style={{display: "flex", justifyContent: "center", gap: 14, marginTop: 20}}>
                {[["At-Tirmidzi", 81.6], ["An-Nasa'i", 82.48], ["Ibnu Majah", 83.2]].map(([n, at]) => {
                  const p = springAt(t, at as number);
                  return (
                    <div key={n as string} style={{opacity: Math.min(1, p * 1.5), transform: `translateY(${(1 - p) * 30}px)`}}>
                      <Chip text={n as string} color={C.goldDeep} bg="#f6efdc" size={26} />
                    </div>
                  );
                })}
              </div>
              <div style={{marginTop: 80, opacity: askIn, transform: `translateY(${(1 - askIn) * 20}px)`}}>
                <div style={{fontFamily: FONT.serif, fontStyle: "italic", fontWeight: 600, fontSize: 62, color: C.inkBrown, lineHeight: 1.15}}>
                  Ia bertanya<br />kepada ayahnya
                </div>
                <svg width={300} height={80} style={{marginTop: 10}}>
                  <circle cx={40} cy={40} r={14} fill={C.goldDeep} />
                  <line x1={60} y1={40} x2={235} y2={40} stroke={C.goldDeep} strokeWidth={3} strokeDasharray="8 8" strokeDashoffset={-t * 40} />
                  <path d="M 232 28 L 252 40 L 232 52" fill="none" stroke={C.goldDeep} strokeWidth={3} />
                  <circle cx={270} cy={40} r={14} fill={C.copper} />
                </svg>
              </div>
            </div>

            {/* D3 — dialog Arab bertahap */}
            <div style={{position: "absolute", top: 100, left: 0, right: 0, display: "flex", flexDirection: "column", alignItems: "center", opacity: c3}}>
              <div style={{opacity: lbl1, fontFamily: FONT.sans, fontWeight: 600, fontSize: 22, letterSpacing: 8, color: C.goldDeep, textTransform: "uppercase", marginBottom: 6}}>Sa'ad bertanya</div>
              {HADITH_SAAD.lines.slice(0, 4).map((ln, i) => (
                <ArabicLine key={i} words={ln.words} times={ln.times} size={64} width={820} color={C.inkBrown} activeColor={C.copper} glow={C.gold} lineHeight={1.62} />
              ))}
              <div style={{margin: "18px 0 4px", opacity: lbl2}}><GoldDivider width={420} progress={lbl2} color={C.goldDeep} /></div>
              <div style={{opacity: lbl2, fontFamily: FONT.sans, fontWeight: 600, fontSize: 22, letterSpacing: 8, color: C.goldDeep, textTransform: "uppercase", marginBottom: 6}}>Sang ayah menjawab</div>
              <ArabicLine words={HADITH_SAAD.lines[4].words} times={HADITH_SAAD.lines[4].times} size={72} width={820} color={C.inkBrown} activeColor={C.copper} glow={C.gold} lineHeight={1.62} />
            </div>

            {/* D4 — terjemahan bertahap */}
            <div style={{position: "absolute", top: 110, left: 0, right: 0, display: "flex", flexDirection: "column", alignItems: "center", opacity: c4}}>
              <div style={{fontFamily: FONT.sans, fontWeight: 600, fontSize: 22, letterSpacing: 8, color: C.goldDeep, textTransform: "uppercase", opacity: trLbl1}}>Artinya · Sa'ad bertanya</div>
              <div style={{marginTop: 18}}><TimedText words={TR_SAAD[0].line} size={80} width={820} color={C.inkBrown} activeColor={C.copper} italic /></div>
              <div style={{marginTop: 12}}><TimedText words={TR_SAAD[1].line} size={60} width={820} color={C.inkBrown} activeColor={C.copper} italic /></div>
              <div style={{marginTop: 12}}><TimedText words={TR_SAAD[2].line} size={68} width={820} color={C.inkBrown} activeColor={C.copper} italic weight={700} /></div>
              <div style={{margin: "30px 0 8px", opacity: trLbl2}}><GoldDivider width={420} progress={trLbl2} color={C.goldDeep} /></div>
              <div style={{fontFamily: FONT.sans, fontWeight: 600, fontSize: 22, letterSpacing: 8, color: C.goldDeep, textTransform: "uppercase", opacity: trLbl2}}>Sang ayah menjawab</div>
              <div style={{marginTop: 14}}><TimedText words={TR_SAAD[3].line} size={66} width={820} color={C.inkBrown} activeColor={C.copper} italic weight={700} /></div>
            </div>
          </Manuscript>
        </div>
      </AbsoluteFill>

      {/* ---- D5: hadis Anas yang sama dipakai Hanafi & Hanbali ---- */}
      <AbsoluteFill style={{opacity: d5, alignItems: "center"}}>
        <div style={{position: "absolute", top: 230, width: 888, textAlign: "center", transform: `translateY(${(1 - d5) * 40}px)`}}>
          <Chip text="Menurut pemahaman Hanafi & Hanbali" size={28} />
          <div style={{marginTop: 34}}>
            <KineticWords
              size={96}
              width={888}
              words={[
                {text: "Mereka", at: 112.48, weight: 700},
                {text: "juga", at: 112.74, weight: 700},
                {text: "berdalil", at: 112.94, weight: 700, color: C.goldLight},
                {text: "dengan", at: 113.42, weight: 700, breakAfter: true},
                {text: "hadis", at: 113.64, weight: 700, italic: true},
                {text: "Anas", at: 113.98, weight: 700, italic: true, color: C.goldLight},
              ]}
            />
          </div>
          <div style={{display: "flex", justifyContent: "center", gap: 22, marginTop: 36}}>
            <div style={{opacity: bk, transform: `translateY(${(1 - bk) * 20}px)`}}><Chip text="Sahih al-Bukhari" size={28} /></div>
            <div style={{opacity: ms, transform: `translateY(${(1 - ms) * 20}px)`}}><Chip text="Sahih Muslim" size={28} /></div>
          </div>
        </div>

        {/* garis waktu: satu bulan → ditinggalkan */}
        <div style={{position: "absolute", top: 1010, left: 96, width: 888, opacity: seg(t, 116.0, 116.7)}}>
          <div style={{display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 16}}>
            <div style={{fontFamily: FONT.sans, fontWeight: 600, fontSize: 24, letterSpacing: 6, color: C.gold, textTransform: "uppercase", opacity: seg(t, 117.04, 117.5)}}>Berqunut</div>
            <div style={{textAlign: "center", opacity: mo, transform: `scale(${0.8 + 0.2 * mo})`}}>
              <div style={{fontFamily: FONT.arabic, fontSize: 64, color: C.goldLight}} dir="rtl">شَهْرًا</div>
              <div style={{fontFamily: FONT.serif, fontWeight: 700, fontSize: 48, color: C.ivory, marginTop: -8}}>sebulan</div>
            </div>
            <div style={{width: 130}} />
          </div>
          <div style={{position: "relative", height: 26, borderRadius: 13, background: "#ffffff18", border: `2px solid ${C.goldDeep}`}}>
            <div style={{position: "absolute", left: 0, top: 0, bottom: 0, width: `${bar * 72}%`, borderRadius: 13, background: `linear-gradient(90deg, ${C.gold}, ${C.goldLight})`, boxShadow: `0 0 30px ${C.gold}`}} />
            <div style={{position: "absolute", left: "72%", top: -14, bottom: -14, width: 4, background: C.copperLight, opacity: Math.min(1, flag * 1.5), boxShadow: `0 0 20px ${C.copper}`}} />
            <div style={{position: "absolute", left: "72%", right: 0, top: 11, borderTop: `3px dashed ${C.parchmentDark}`, opacity: 0.4 * flag}} />
          </div>
          <div style={{position: "relative", height: 150, marginTop: 24}}>
            <div style={{position: "absolute", left: "72%", transform: `translateX(-50%) scale(${0.8 + 0.2 * flag})`, opacity: Math.min(1, flag * 1.5), textAlign: "center", width: 360}}>
              <div style={{fontFamily: FONT.arabic, fontSize: 64, color: C.copperLight}} dir="rtl">ثُمَّ تَرَكَهُ</div>
              <div style={{fontFamily: FONT.serif, fontWeight: 700, fontSize: 46, color: C.ivory, marginTop: -6}}>lalu ditinggalkan</div>
            </div>
          </div>
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
