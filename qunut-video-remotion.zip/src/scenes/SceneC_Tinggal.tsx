import React from "react";
import {AbsoluteFill} from "remotion";
import {C, FONT} from "../theme";
import {easeInOut, easeOut, lerp, seg, springAt, useT} from "../helpers/anim";
import {ArabicLine, KineticWords, TimedText} from "../components/Text";
import {Chip, GoldDivider} from "../components/Ornaments";
import {Glass, Manuscript} from "../components/Panels";
import {HADITH_TINGGAL, TR_TINGGAL} from "../data/timeline";

const RefCard: React.FC<{latin: string; arabic: string; p: number}> = ({latin, arabic, p}) => (
  <div style={{opacity: p, transform: `translateX(${(1 - p) * 120}px) rotate(${(1 - p) * 4}deg)`}}>
    <Glass width={700} height={170} glow={p * 0.6}>
      <div style={{position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 52px"}}>
        <div style={{fontFamily: FONT.serif, fontWeight: 700, fontSize: 56, color: C.ivory}}>{latin}</div>
        <div style={{fontFamily: FONT.arabic, fontSize: 62, color: C.goldLight}} dir="rtl">{arabic}</div>
      </div>
    </Glass>
  </div>
);

const Layer: React.FC<{n: string; title: string; sub: string; p: number; color: string; strike?: number}> = ({n, title, sub, p, color, strike = 0}) => (
  <div style={{opacity: p, transform: `translateY(${(1 - p) * 40}px)`}}>
    <Glass width={888} height={228} color={color} glow={p * 0.5}>
      <div style={{position: "absolute", inset: 0, display: "flex", alignItems: "center", gap: 34, padding: "0 46px"}}>
        <div style={{fontFamily: FONT.serif, fontWeight: 700, fontSize: 110, color, lineHeight: 1}}>{n}</div>
        <div>
          <div style={{fontFamily: FONT.sans, fontWeight: 600, fontSize: 22, letterSpacing: 6, textTransform: "uppercase", color}}>{sub}</div>
          <div style={{position: "relative", fontFamily: FONT.serif, fontWeight: 700, fontSize: 54, lineHeight: 1.08, color: C.ivory, marginTop: 6}}>
            {title}
            {strike > 0 && <div style={{position: "absolute", left: 0, top: "52%", height: 4, width: `${strike * 100}%`, background: C.copperLight}} />}
          </div>
        </div>
      </div>
    </Glass>
  </div>
);

export const SceneC: React.FC = () => {
  const t = useT();
  const cardIn = seg(t, 41.6, 42.4, easeOut);
  const qOut = seg(t, 44.35, 44.75);
  const shrink = seg(t, 63.2, 63.9, easeInOut);
  const cardScale = lerp(1, 0.5, shrink);
  const cardY = lerp(0, -135, shrink);

  const bukhari = seg(t, 45.3, 45.8, easeOut);
  const muslim = seg(t, 45.84, 46.4, easeOut);
  const anas = seg(t, 46.6, 47.1, easeOut);
  const refsOut = seg(t, 47.4, 47.9);

  const hdrIn = seg(t, 47.7, 48.3, easeOut);
  const arabicDim = 1 - 0.0 * seg(t, 55, 56);
  const trIn = seg(t, 55.06, 55.6);

  const diagIn = seg(t, 63.5, 64.2, easeOut);
  const phrase = springAt(t, 63.7);
  const l1 = seg(t, 65.2, 65.9, easeOut);
  const l2 = seg(t, 68.2, 68.9, easeOut);
  const strike = seg(t, 66.4, 67.6, easeInOut);
  const note = seg(t, 68.9, 69.3, easeOut);
  const tail = seg(t, 69.2, 69.5);

  return (
    <AbsoluteFill style={{alignItems: "center", opacity: 1 - tail * 0}}>
      <div style={{position: "absolute", top: 330, transformOrigin: "50% 0%", transform: `translateY(${cardY + (1 - cardIn) * 120}px) scale(${cardScale})`, opacity: cardIn}}>
        <Manuscript width={920} height={1080} reveal={cardIn} label="Riwayat Anas bin Malik">
          {/* C1 — pertanyaan */}
          <div style={{position: "absolute", top: 230, left: 0, right: 0, display: "flex", justifyContent: "center", opacity: 1 - qOut, transform: `scale(${1 - qOut * 0.1})`}}>
            <KineticWords
              size={112}
              width={800}
              color={C.inkBrown}
              words={[
                {text: "Bagaimana", at: 41.72, weight: 700},
                {text: "dengan", at: 42.14, weight: 700},
                {text: "hadis", at: 42.34, weight: 700, color: C.copper},
                {text: "bahwa", at: 42.8, weight: 700},
                {text: "Nabi", at: 43.12, weight: 700, color: C.copper},
                {text: "meninggalkan", at: 43.42, weight: 700, color: C.copper, italic: true},
                {text: "qunut?", at: 43.96, weight: 700, color: C.copper, italic: true},
              ]}
            />
          </div>

          {/* C2 — referensi */}
          <div style={{position: "absolute", top: 190, left: 0, right: 0, display: "flex", flexDirection: "column", alignItems: "center", gap: 26, opacity: (1 - refsOut) * seg(t, 44.7, 45.2)}}>
            <div style={{fontFamily: FONT.sans, fontWeight: 600, fontSize: 24, letterSpacing: 8, color: C.goldDeep, textTransform: "uppercase"}}>Dalam riwayat</div>
            <RefCard latin="Sahih al-Bukhari" arabic="صحيح البخاري" p={bukhari} />
            <RefCard latin="Sahih Muslim" arabic="صحيح مسلم" p={muslim} />
            <div style={{opacity: anas, fontFamily: FONT.serif, fontStyle: "italic", fontWeight: 600, fontSize: 60, color: C.inkBrown}}>Anas berkata,</div>
          </div>

          {/* C3/C4 — teks Arab + terjemahan */}
          <div style={{position: "absolute", top: 120, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 14, opacity: hdrIn}}>
            <Chip text="Bukhari" color={C.goldDeep} bg="#f6efdc" size={22} />
            <Chip text="Muslim" color={C.goldDeep} bg="#f6efdc" size={22} />
          </div>
          <div style={{position: "absolute", top: 205, left: 0, right: 0, display: "flex", justifyContent: "center", opacity: arabicDim}}>
            <ArabicLine
              words={HADITH_TINGGAL.words}
              times={HADITH_TINGGAL.times}
              size={88}
              width={800}
              color={C.inkBrown}
              activeColor={C.copper}
              glow={C.gold}
              lineHeight={1.75}
              highlights={[
                {i0: 9, i1: 10, t0: 53.84, t1: 54.9, color: C.copper},
                {i0: 4, i1: 4, t0: 57.2, t1: 58.0, color: C.emeraldLight},
                {i0: 5, i1: 8, t0: 58.18, t1: 61.3, color: C.emeraldLight},
                {i0: 9, i1: 10, t0: 61.56, t1: 63.3, color: C.copper},
              ]}
            />
          </div>
          <div style={{position: "absolute", top: 745, left: 0, right: 0, display: "flex", flexDirection: "column", alignItems: "center", opacity: trIn}}>
            <GoldDivider width={460} progress={seg(t, 55.06, 55.8, easeOut)} color={C.goldDeep} />
            <div style={{marginTop: 10}}>
              <TimedText words={TR_TINGGAL} size={50} width={800} color={C.inkBrown} activeColor={C.copper} italic />
            </div>
          </div>
        </Manuscript>
      </div>

      {/* C5 — dua lapisan interpretasi (menurut Syafi'iyah) */}
      <div style={{position: "absolute", top: 905, left: 96, width: 888, opacity: diagIn}}>
        <div style={{display: "flex", justifyContent: "center", transform: `scale(${0.8 + 0.2 * phrase})`}}>
          <Chip text="Menurut pemahaman Syafi'iyah" size={30} />
        </div>
        <div style={{display: "flex", flexDirection: "column", alignItems: "center", marginTop: 22}}>
          <div style={{fontFamily: FONT.arabic, fontSize: 84, color: C.goldLight, textShadow: `0 0 40px ${C.gold}`}} dir="rtl">ثُمَّ تَرَكَهُ</div>
        </div>
        <svg width={888} height={70} style={{display: "block"}}>
          <path d="M 444 4 C 444 36, 220 30, 220 66" stroke={C.gold} strokeWidth={3} fill="none" strokeDasharray="300" strokeDashoffset={300 * (1 - l1)} />
          <path d="M 444 4 C 444 36, 668 30, 668 66" stroke={C.copperLight} strokeWidth={3} fill="none" strokeDasharray="300" strokeDashoffset={300 * (1 - l2)} />
        </svg>
        <div style={{display: "flex", flexDirection: "column", gap: 24, marginTop: 4}}>
          <Layer n="1" sub="Lapisan pertama · yang ditinggalkan" title="Doa laknat atas kabilah itu" p={l1} color={C.gold} />
          <Layer n="2" sub="Lapisan kedua · bukan yang ditinggalkan" title="Qunut Subuh" p={l2} color={C.emeraldLight} strike={0} />
        </div>
        <div style={{textAlign: "center", marginTop: 26, fontFamily: FONT.serif, fontStyle: "italic", fontWeight: 500, fontSize: 40, color: C.parchmentDark, opacity: note}}>
          Ulama lain memahaminya berbeda
        </div>
      </div>
    </AbsoluteFill>
  );
};
