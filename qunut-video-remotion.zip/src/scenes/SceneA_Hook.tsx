import React from "react";
import {AbsoluteFill, random} from "remotion";
import {C, FONT, H, W} from "../theme";
import {easeInOut, easeOut, lerp, seg, springAt, useT} from "../helpers/anim";
import {Mosque} from "../components/Mosque";
import {PrayerFigure, POSES} from "../components/PrayerFigure";
import {KineticWords} from "../components/Text";
import {Star8} from "../components/Ornaments";

/**
 * ADEGAN A — HOOK (0 – 12,8 dtk)
 * Dunia 2 layar lebar: masjid A (qunut, kiri) dan masjid B (tanpa qunut, kanan). Kamera bergeser mengikuti kalimat.
 */
const Stars: React.FC<{t: number; offset: number}> = ({t, offset}) => (
  <>
    {Array.from({length: 70}).map((_, i) => {
      const x = random(`sx${i}`) * W * 2;
      const y = random(`sy${i}`) * 900;
      const tw = 0.3 + 0.7 * Math.abs(Math.sin(t * (0.5 + random(`st${i}`) * 1.5) + i));
      return <div key={i} style={{position: "absolute", left: x + offset, top: y, width: 3, height: 3, borderRadius: "50%", background: C.ivory, opacity: tw * 0.8}} />;
    })}
  </>
);

const Medallion: React.FC<{raise: number; label: string; color: string; appear: number}> = ({raise, label, color, appear}) => (
  <div style={{opacity: appear, transform: `translateY(${(1 - appear) * 40}px)`, display: "flex", flexDirection: "column", alignItems: "center", gap: 16}}>
    <div style={{width: 320, height: 320, borderRadius: "50%", border: `3px solid ${color}`, background: "#04100fcc", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 60px ${color}55`, overflow: "hidden"}}>
      <PrayerFigure pose={POSES.itidal} raise={raise} size={290} color={C.goldLight} />
    </div>
    <div style={{fontFamily: FONT.sans, fontWeight: 600, fontSize: 28, letterSpacing: 6, textTransform: "uppercase", color}}>{label}</div>
  </div>
);

export const SceneA: React.FC = () => {
  const t = useT();
  // Cahaya mengungkap dari gelap
  // Kamera: masjid A (x=0) → masjid B (x=-W) pada "di masjid lain tidak" → mundur (zoom out) pada "Apakah salah satunya keliru?"
  const pan = seg(t, 3.7, 4.9, easeInOut);
  const zoomOut = seg(t, 5.4, 6.9, easeInOut);
  const camX = lerp(0, -W, pan) + lerp(0, W / 2, zoomOut);
  const scale = lerp(1, 0.52, zoomOut);
  const camY = lerp(0, 120, zoomOut);
  const fall = seg(t, 7.35, 8.05, easeOut); // pertanyaan runtuh
  const idea = seg(t, 8.9, 9.7, easeOut);
  const converge = seg(t, 11.0, 12.4, easeInOut);

  const raiseA = seg(t, 2.3, 3.2, easeOut);
  const medAppear = seg(t, 3.0, 3.8, easeOut);
  const medBAppear = seg(t, 4.6, 5.4, easeOut);

  const impact = springAt(t, 7.95, {damping: 9, stiffness: 180, mass: 0.8});
  const shock = seg(t, 7.95, 8.9, easeOut);

  return (
    <AbsoluteFill>
      {/* Dunia lebar */}
      <AbsoluteFill style={{transform: `translate(${camX}px, ${camY}px) scale(${scale})`, transformOrigin: "50% 50%"}}>
        <div style={{position: "absolute", left: 0, top: 0, width: W * 2, height: H}}>
          {/* langit fajar (diperluas jauh agar tidak terlihat tepinya saat kamera mundur) */}
          <div style={{position: "absolute", left: -W * 3, top: -H, width: W * 5, height: H * 3, background: `linear-gradient(180deg, #021210 0px, #0a3a30 ${H + 700}px, #a0652f ${H + 1060}px, #e0a458 ${H + 1125}px, #05120f ${H + 1126}px, #020a09 100%)`}} />
          <div style={{position: "absolute", left: W, top: -H, width: W * 4, height: H * 3, background: `linear-gradient(180deg, #020d14 0px, #0b3140 ${H + 700}px, #2f7f86 ${H + 1060}px, #a9d6d3 ${H + 1125}px, #05120f ${H + 1126}px, #020a09 100%)`, WebkitMaskImage: "linear-gradient(90deg, transparent 0px, #000 420px)", maskImage: "linear-gradient(90deg, transparent 0px, #000 420px)"}} />
          <Stars t={t} offset={-camX * 0.15} />
          {/* masjid A */}
          <div style={{position: "absolute", left: 0, top: 300, width: W, display: "flex", justifyContent: "center"}}>
            <Mosque variant={1} glow={C.gold} width={760} id="mA" lit={0.5 + 0.5 * seg(t, 0.6, 2.4)} />
          </div>
          {/* masjid B */}
          <div style={{position: "absolute", left: W, top: 300, width: W, display: "flex", justifyContent: "center"}}>
            <Mosque variant={2} glow={C.teal} width={760} id="mB" lit={0.5 + 0.5 * seg(t, 0.6, 2.4)} />
          </div>
          {/* medali shalat Subuh kontekstual */}
          <div style={{position: "absolute", left: 0, top: 1215, width: W, display: "flex", justifyContent: "center"}}>
            <Medallion raise={raiseA} label="Subuh: dengan qunut" color={C.gold} appear={medAppear} />
          </div>
          <div style={{position: "absolute", left: W, top: 1215, width: W, display: "flex", justifyContent: "center"}}>
            <Medallion raise={0} label="Subuh: tanpa qunut" color={C.teal} appear={medBAppear} />
          </div>
          {/* tanah */}
          
        </div>
      </AbsoluteFill>

      {/* Kinetic typography — pertanyaan */}
      <AbsoluteFill style={{alignItems: "center", justifyContent: "flex-start", paddingTop: 300}}>
        <div style={{opacity: 1 - fall, transform: `translateY(${-fall * 80}px) scale(${1 - fall * 0.2})`, filter: `blur(${fall * 14}px)`}}>
          <KineticWords
            size={128}
            width={900}
            words={[
              {text: "Apakah", at: 5.68, weight: 700, breakAfter: true},
              {text: "salah", at: 5.98, weight: 700, color: C.goldLight},
              {text: "satunya", at: 6.22, weight: 700, color: C.goldLight, breakAfter: true},
              {text: "keliru?", at: 6.54, weight: 700, italic: true, color: C.copperLight},
            ]}
          />
        </div>
      </AbsoluteFill>

      {/* Jawaban: TIDAK. */}
      <AbsoluteFill style={{alignItems: "center", justifyContent: "center"}}>
        {shock > 0 && shock < 1 && (
          <div style={{position: "absolute", width: 300 + shock * 1700, height: 300 + shock * 1700, borderRadius: "50%", border: `${10 * (1 - shock) + 1}px solid ${C.goldLight}`, opacity: 1 - shock, boxShadow: `0 0 80px ${C.gold}`}} />
        )}
        {t > 7.4 && (
          <div style={{textAlign: "center", transform: `scale(${0.6 + 0.4 * impact})`, opacity: seg(t, 7.4, 7.9) * (1 - seg(t, 8.9, 9.5))}}>
            <div style={{fontFamily: FONT.sans, fontWeight: 600, fontSize: 30, letterSpacing: 14, color: C.gold, marginBottom: 10}}>JAWABANNYA</div>
            <div style={{fontFamily: FONT.serif, fontWeight: 700, fontSize: 250, lineHeight: 0.9, color: C.ivory, textShadow: `0 0 90px ${C.gold}`, letterSpacing: 8}}>
              {t > 7.98 ? "TIDAK." : ""}
            </div>
          </div>
        )}
      </AbsoluteFill>

      {/* Gagasan utama */}
      <AbsoluteFill style={{alignItems: "center", justifyContent: "flex-start", paddingTop: 230, opacity: idea}}>
        <div style={{transform: `translateY(${(1 - idea) * 40}px)`}}>
          <Star8 size={64} rotate={t * 20} />
        </div>
        <div style={{marginTop: 24}}>
          <KineticWords
            size={104}
            width={900}
            words={[
              {text: "Perbedaan", at: 9.1, weight: 700, breakAfter: true},
              {text: "pendapat", at: 9.82, weight: 700, color: C.goldLight},
              {text: "ulama", at: 10.3, weight: 700, color: C.goldLight},
            ]}
          />
        </div>
      </AbsoluteFill>

      {/* Dua cahaya bertemu pada gulungan "Dalil" */}
      <AbsoluteFill style={{opacity: seg(t, 10.9, 11.6)}}>
        <svg width={W} height={H} style={{position: "absolute", inset: 0}}>
          <defs>
            <filter id="aglow"><feGaussianBlur stdDeviation="6" /></filter>
          </defs>
          {[
            {x: 200, c: C.gold},
            {x: 880, c: C.teal},
          ].map((m, i) => {
            const len = converge;
            const x = lerp(m.x, 540, len);
            const y = lerp(1130, 1000, len);
            return (
              <g key={i}>
                <line x1={m.x} y1={1130} x2={x} y2={y} stroke={m.c} strokeWidth={5} filter="url(#aglow)" opacity={0.9} />
                <line x1={m.x} y1={1130} x2={x} y2={y} stroke={C.ivory} strokeWidth={2} />
                <circle cx={m.x} cy={1130} r={14} fill={m.c} />
              </g>
            );
          })}
        </svg>
        <div style={{position: "absolute", left: 0, right: 0, top: 880, display: "flex", justifyContent: "center", opacity: seg(t, 11.8, 12.3) , transform: `scale(${0.7 + 0.3 * springAt(t, 11.9)})`}}>
          <div style={{textAlign: "center"}}>
            <div style={{width: 300, height: 160, margin: "0 auto", borderRadius: 14, background: `linear-gradient(180deg, ${C.parchment}, ${C.parchmentDark})`, border: `4px solid ${C.goldDeep}`, boxShadow: `0 0 80px ${C.gold}aa`, display: "flex", alignItems: "center", justifyContent: "center"}}>
              <div style={{fontFamily: FONT.serif, fontWeight: 700, fontSize: 80, color: C.inkBrown}}>Dalil</div>
            </div>
            <div style={{fontFamily: FONT.arabic, fontSize: 70, color: C.goldLight, marginTop: 4}}>الدَّلِيلُ</div>
          </div>
        </div>
      </AbsoluteFill>

    </AbsoluteFill>
  );
};
