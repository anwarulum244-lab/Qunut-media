import React from "react";
import {AbsoluteFill, Audio, Sequence, staticFile, useVideoConfig} from "remotion";
import "./fonts";
import {Backdrop} from "./components/Backdrop";
import {Transitions} from "./components/Transitions";
import {Scene, easeInOut, seg, sec, useT} from "./helpers/anim";
import {RECITATION_WINDOWS, SCENE_START} from "./data/timeline";
import {SceneA} from "./scenes/SceneA_Hook";
import {SceneB} from "./scenes/SceneB_Syafii";
import {SceneC} from "./scenes/SceneC_Tinggal";
import {SceneD} from "./scenes/SceneD_HanafiHanbali";
import {SceneE} from "./scenes/SceneE_Maliki";
import {SceneF} from "./scenes/SceneF_Inti";
import {SceneG} from "./scenes/SceneG_Kitab";
import {SceneH} from "./scenes/SceneH_Penutup";

export type QunutProps = {durationInSeconds: number};

/** Sound effect (dibuat sendiri via scripts/gen_audio.py). Tidak ada yang ditempatkan di atas pembacaan Arab. */
type Sfx = {at: number; file: string; vol: number};
const SFX: Sfx[] = [
  {at: 1.2, file: "sfx_whoosh", vol: 0.16},
  {at: 3.75, file: "sfx_whoosh_short", vol: 0.22},
  {at: 5.68, file: "sfx_tick", vol: 0.28},
  {at: 6.54, file: "sfx_tick", vol: 0.28},
  {at: 7.92, file: "sfx_impact", vol: 0.55},
  {at: 12.4, file: "sfx_whoosh", vol: 0.35},
  {at: 13.4, file: "sfx_tick", vol: 0.25},
  {at: 18.94, file: "sfx_impact", vol: 0.3},
  {at: 19.45, file: "sfx_paper", vol: 0.35},
  {at: 24.0, file: "sfx_tick", vol: 0.18},
  {at: 36.95, file: "sfx_whoosh_short", vol: 0.25},
  {at: 40.0, file: "sfx_tick", vol: 0.25},
  {at: 41.1, file: "sfx_paper", vol: 0.55},
  {at: 45.3, file: "sfx_tick", vol: 0.22},
  {at: 54.8, file: "sfx_impact", vol: 0.28},
  {at: 63.35, file: "sfx_whoosh_short", vol: 0.3},
  {at: 69.2, file: "sfx_whoosh", vol: 0.4},
  {at: 77.2, file: "sfx_whoosh_short", vol: 0.3},
  {at: 85.85, file: "sfx_paper", vol: 0.3},
  {at: 99.7, file: "sfx_tick", vol: 0.2},
  {at: 112.15, file: "sfx_whoosh_short", vol: 0.3},
  {at: 118.1, file: "sfx_impact", vol: 0.25},
  {at: 119.2, file: "sfx_whoosh", vol: 0.38},
  {at: 124.9, file: "sfx_whoosh_short", vol: 0.25},
  {at: 132.2, file: "sfx_paper", vol: 0.3},
  {at: 134.3, file: "sfx_tick", vol: 0.22},
  {at: 135.22, file: "sfx_tick", vol: 0.22},
  {at: 137.32, file: "sfx_tick", vol: 0.22},
  {at: 139.46, file: "sfx_tick", vol: 0.22},
  {at: 141.2, file: "sfx_whoosh", vol: 0.32},
  {at: 144.44, file: "sfx_chime", vol: 0.22},
  {at: 147.4, file: "sfx_tick", vol: 0.25},
  {at: 149.5, file: "sfx_tick", vol: 0.18},
];

/** Volume musik latar: rendah, dan makin rendah saat pembacaan hadis Arab. */
const musicVolume = (frame: number, total: number) => {
  const t = frame / 30;
  let v = 0.075;
  for (const [a, b] of RECITATION_WINDOWS) {
    const down = seg(t, a - 0.6, a, (x) => x) * (1 - seg(t, b, b + 0.8, (x) => x));
    v = Math.min(v, 0.075 - 0.05 * down);
  }
  const fadeOut = 1 - seg(t, total / 30 - 3, total / 30, (x) => x);
  const fadeIn = seg(t, 0, 2.5, (x) => x);
  return Math.max(0, v * fadeIn * fadeOut);
};

const Curtain: React.FC<{total: number}> = ({total}) => {
  const t = useT();
  const end = total / 30;
  const open = 1 - seg(t, 0.0, 2.0, easeInOut);
  const close = 0.75 * seg(t, end - 1.0, end - 0.02, easeInOut);
  return <AbsoluteFill style={{background: "#000", opacity: Math.max(open, close), pointerEvents: "none"}} />;
};

export const QunutVideo: React.FC<QunutProps> = ({durationInSeconds}) => {
  const {durationInFrames} = useVideoConfig();
  const S = SCENE_START;
  return (
    <AbsoluteFill style={{background: "#000"}}>
      {/* MASTER TIMELINE: voice-over asli, tidak diubah (tanpa trim, tanpa playbackRate) */}
      <Audio src={staticFile("qunut_edit.mp3")} volume={1} />
      <Audio src={staticFile("audio/music_pad.mp3")} volume={(f) => musicVolume(f, durationInFrames)} />
      {SFX.map((s, i) => (
        <Sequence key={i} from={sec(s.at)} durationInFrames={sec(2.5)} layout="none">
          <Audio src={staticFile(`audio/${s.file}.mp3`)} volume={s.vol} />
        </Sequence>
      ))}

      <Backdrop />

      <Scene name="A · Hook" from={S.A} to={S.B}><SceneA /></Scene>
      <Scene name="B · Syafi'i" from={S.B} to={S.C}><SceneB /></Scene>
      <Scene name="C · Hadis meninggalkan qunut" from={S.C} to={S.D}><SceneC /></Scene>
      <Scene name="D · Hanafi & Hanbali" from={S.D} to={S.E}><SceneD /></Scene>
      <Scene name="E · Maliki" from={S.E} to={S.F}><SceneE /></Scene>
      <Scene name="F · Inti perbedaan" from={S.F} to={S.G}><SceneF /></Scene>
      <Scene name="G · Rujukan kitab" from={S.G} to={S.H}><SceneG /></Scene>
      <Scene name="H · Penutup" from={S.H} to={durationInSeconds}><SceneH endSec={durationInSeconds} /></Scene>

      <Transitions />
      <Curtain total={durationInFrames} />
    </AbsoluteFill>
  );
};
