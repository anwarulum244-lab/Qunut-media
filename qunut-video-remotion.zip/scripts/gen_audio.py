#!/usr/bin/env python3
"""Sintesis sound effect & musik latar ORIGINAL (tanpa aset pihak ketiga).
Semua suara dibuat dari noise/sinus -> bebas hak cipta. Jalankan: python3 scripts/gen_audio.py
Membutuhkan: numpy, ffmpeg."""
import numpy as np, subprocess, wave, os
SR = 44100
OUT = os.path.join(os.path.dirname(__file__), "..", "public", "audio")
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(7)

def save(name, x):
    x = np.clip(x, -1, 1)
    st = np.stack([x, x], 1) if x.ndim == 1 else x
    pcm = (st * 32767).astype(np.int16)
    wav = os.path.join(OUT, name + ".wav")
    with wave.open(wav, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-b:a", "192k", os.path.join(OUT, name + ".mp3")], check=True)
    os.remove(wav)

def lp(x, fc):
    a = np.exp(-2 * np.pi * fc / SR); y = np.zeros_like(x); s = 0.0
    for i, v in enumerate(x):
        s = (1 - a) * v + a * s; y[i] = s
    return y

def whoosh(dur=1.1, f0=300, f1=3200):
    n = int(dur * SR); t = np.linspace(0, 1, n)
    noise = rng.standard_normal(n)
    fc = f0 * (f1 / f0) ** (t ** 1.4)
    y = np.zeros(n); s = 0.0
    for i in range(n):
        a = np.exp(-2 * np.pi * fc[i] / SR); s = (1 - a) * noise[i] + a * s; y[i] = s
    env = np.sin(np.pi * t) ** 2.2
    y = y * env; y /= np.abs(y).max() + 1e-9
    return y * 0.5

def paper(dur=0.7):
    n = int(dur * SR); t = np.linspace(0, 1, n)
    noise = rng.standard_normal(n)
    hp = noise - lp(noise, 1800)
    env = (np.exp(-t * 6) * (0.4 + 0.6 * np.abs(np.sin(t * 40 * np.pi)) ** 3)) * np.minimum(1, t * 60)
    y = hp * env; y /= np.abs(y).max() + 1e-9
    return y * 0.45

def impact(dur=1.4, f=62):
    n = int(dur * SR); t = np.arange(n) / SR
    body = np.sin(2 * np.pi * (f + 40 * np.exp(-t * 18)) * t) * np.exp(-t * 3.2)
    click = lp(rng.standard_normal(n), 900) * np.exp(-t * 40) * 0.5
    shimmer = (np.sin(2 * np.pi * 528 * t) + 0.5 * np.sin(2 * np.pi * 792 * t)) * np.exp(-t * 4) * 0.06
    return (body * 0.9 + click + shimmer) * 0.8

def tick(dur=0.35):
    n = int(dur * SR); t = np.arange(n) / SR
    return (np.sin(2 * np.pi * 1320 * t) + 0.4 * np.sin(2 * np.pi * 1980 * t)) * np.exp(-t * 14) * 0.35

def chime(dur=2.2):
    n = int(dur * SR); t = np.arange(n) / SR; y = np.zeros(n)
    for k, f in enumerate([523.25, 659.25, 783.99]):
        d = int(k * 0.16 * SR)
        seg = np.sin(2 * np.pi * f * t[: n - d]) * np.exp(-t[: n - d] * 2.4)
        y[d:] += seg * 0.25
    return y

def pad(dur=156.0):
    n = int(dur * SR); t = np.arange(n) / SR; y = np.zeros(n)
    # progresi lembut: Dm - Bb - Gm - A (drone panjang, kuinta terbuka)
    chords = [[146.83, 220.0, 293.66, 349.23], [116.54, 174.61, 233.08, 293.66],
              [98.0, 146.83, 196.0, 233.08], [110.0, 164.81, 220.0, 277.18]]
    seg = dur / 8.0
    for i in range(8):
        ch = chords[i % 4]; a = int(i * seg * SR); b = min(n, int((i + 1) * seg * SR) + int(3 * SR))
        tt = t[a:b] - t[a]
        env = np.minimum(1, tt / 3.0) * np.minimum(1, (t[b - 1] - t[a:b]) / 3.0 + 0.0)
        env = np.clip(env, 0, 1)
        for f in ch:
            for det in (-0.4, 0.4):
                y[a:b] += np.sin(2 * np.pi * (f + det) * tt + rng.uniform(0, 6.28)) * env * 0.05
            y[a:b] += np.sin(2 * np.pi * f * 2 * tt) * env * 0.012
    lfo = 0.85 + 0.15 * np.sin(2 * np.pi * 0.07 * t)
    y *= lfo
    fade = np.minimum(1, t / 4.0) * np.minimum(1, (dur - t) / 6.0)
    return y * fade / (np.abs(y).max() + 1e-9) * 0.7

save("sfx_whoosh", whoosh())
save("sfx_whoosh_short", whoosh(0.7, 500, 4500))
save("sfx_paper", paper())
save("sfx_impact", impact())
save("sfx_tick", tick())
save("sfx_chime", chime())
save("music_pad", pad())
print("selesai ->", OUT)
