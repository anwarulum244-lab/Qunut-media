# Laporan

## Status pengujian (jujur)
- `tsc --noEmit`: lolos.
- Still diuji pada ±18 frame di semua adegan (A–H) → tampilan, font Arab (Amiri, harakat & ﷺ), RTL benar.
- Klip uji 78 frame terakhir (skala 0,25) dirender → H.264 + AAC, 30 fps, audio terdengar.
- **Render penuh 1080×1920 BELUM dijalankan** di lingkungan saya (1 CPU, GL perangkat lunak ≈5 dtk/frame ≈ 7 jam). Jalankan `npm run render` di komputer Anda.
- Sinkronisasi diperiksa lewat timestamp kata hasil transkripsi otomatis + still; belum ditonton real-time end-to-end. Mohon cek di Studio, terutama titik: 18,94 dtk (qunut Syafi'i), 53,84 (ثُمَّ تَرَكَهُ), 86–99,6 (dialog Sa'ad), 134–141 (kitab).

## Catatan ilmiah (naskah TIDAK diubah)
1. Teks Arab hadis diambil dari prompt Anda; tidak ada nomor hadis/halaman ditambahkan.
2. Hadis kedua (قَنَتَ ... ثُمَّ تَرَكَهُ) tampak redaksi gabungan; riwayat Bukhari/Muslim berbeda lafaz. Mohon verifikasi redaksi sebelum publikasi.
3. Narasi menyebut Hanafi & Hanbali sama-sama "qunut hanya pada witir dan musibah". Rincian internal mazhab (mis. qunut nazilah menurut Hanafi) lebih beragam; visual mengikuti narasi apa adanya.
4. Narasi menyebut hadis Anas (qunut sampai wafat) "diriwayatkan Ahmad dan Daruquthni"; diikuti apa adanya.
5. Label Arab tambahan yang saya buat: nama kitab (الأم، المجموع، الهداية، المغني), صحيح البخاري/مسلم, الدَّلِيلُ. Mohon cek.
6. Transkripsi otomatis keliru mengeja beberapa kata (mis. "kunut"); teks di layar memakai ejaan yang dirapikan.

## Aset
Tidak ada aset pihak ketiga selain font OFL (Amiri, Cormorant Garamond, Inter via @fontsource). SFX & musik pad disintesis sendiri (`scripts/gen_audio.py`). Ilustrasi masjid/figur/kitab = SVG buatan sendiri (tanpa foto).
